# Team handoff: RESPOND Regional reference build

This is an **independent, runnable reference implementation**, not an in-place edit to the existing team Git repository. It implements the latest regional UX request while taking the uploaded *RESPOND Team Build Plan 2* as design context. The PDF's canonical Vite/React/TypeScript contract and folder ownership still control how the team integrates changes.

## What changed architecturally

1. **Region-scale planning** replaces per-person tasks. A task is an irregular geo-located region, with an expected population count, current survey fraction, aggregated found count, threat score and independent event IDs. No person names are presented in task views.
2. **Population accounting** uses a typed assignment array of exactly one region ID per synthetic individual. Expected residents remain an initial baseline, whereas `present` shifts when the civilian movement model reallocates residents. `World.populationValid()` validates the invariant after migrations/manual additions.
3. **Actor autonomy**: an agent is constructed with only public region attributes and peer/team launch information. Hidden `atRisk` and live population assignments remain in `World`. Survey results are released as observations only when the agent reaches the region. Actors gossip *delta event logs* on connection (idempotent IDs), avoiding whole-log floods with many actors.
4. **Movement**: drone motion interpolates between free geographic positions; car/foot/boat motion follows shortest paths of a geographic road graph. No grid cell stepping.
5. **Presentation**: regional blobs and sparse drone markers are the default. A toggle reveals all responders and another reveals initial launch positions. Street/topographic tile layers are optional; offline mode is self-contained.
6. **Manual search tasks**: command adds a regional task while the clock is running. It is not instantly injected into disconnected actors; a `ADD_REGION` event propagates on reconnection.

## Merge ownership (per the team PDF)

- **CS1 — scenario, simulation, map:** port region generation and map layers; maintain OSM geometry preparation, flood changes and routing. Add actual Overpass import as a scripted, repeatable build step if appropriate.
- **CS2 — agents:** port local search-region belief, regional task allocation, Q-valued strategy selection, incremental peer gossip and takeover. Integrate with `AgentLike.step(Perception, inbox)` and respect the no-`src/sim/`-imports rule.
- **CS3 — panels, gateway, App:** port the four headline counters, map-mode toggles, regional task list, warning badges and approval/hold workflow. Translate the new region/survey event schema into the gateway contract **only by team agreement**; do not silently replace `src/shared/types.ts`.
- **Presentation teammate:** demonstrate 50k scale, mast down, a lost drone, cover-reallocation, a boat-only route, a manually added region and commander authorization; label all derived/synthetic data accurately.

## Schema changes that need team approval

The uploaded PDF's `FieldEvent` and `Scenario` contracts are person-based. This reference introduces `Region`, `SURVEY`, `ADD_REGION`, region-population counts, and an agent-local progress record. These types **cannot be pasted into the current team project unchanged**. Propose additive optional types, agree with CS1/CS2/CS3, then update the canonical `docs/PLAN.md` before integration.

## Live disaster-data safeguards

Do not present OSM imagery as evidence of flood damage. Importing authentic OSM roads makes road geometry real but does not validate closures, passability, hazard severity or modelled ETAs. Before any operational use, replace synthetic hazard inputs with verified, timestamped local authority/geospatial feeds and put a trained human in the decision loop. The current app is only a hackathon demonstration.

## v5 integration changes — drone sectors, rescue holds and commander isolation

1. **CS1 / scenario and mapping:** introduce an equal-area `Sector` type (geographical rectangle bounds in metres, centre GPS, owning drone ID) and `launchSites`. The base span is scaled by `sqrt(droneCount / 4)` (with a safe fallback for zero drones) so total area scales with the drone fleet. Add the perimeter and sector boundaries on the map. Separate the static SVG tile group from the dynamic overlay to prevent reloading remote tiles every tick. Test all 20 sector counts.
2. **CS2 / agent logic:** extend the drone agent with local track history, cumulative metres flown, instantaneous speed, local confirmed count, assigned sector and rescue-wait state. Once at least `ceil(0.99 * expected)` people are located, a drone can choose the next zone, but rescue waiting takes precedence until a responder physically arrives. Stale heartbeat takeover is a deliberate exception allowing a survivor to enter a failed drone's sector. Do not leak simulator ground truth to the agent.
3. **CS1+CS2 / rescue assignment:** calculate nearest available **non-drone** responder using its current location, vehicle road-passability and modelled route cost. Assign only this unit and keep other routes/tasks intact. Hold queued dispatches during the simulated mast blackout until delivery is possible. On arrival, release the waiting drone.
4. **CS3 / commander and local UX:** create command and Drone POV tabs. During mast failure, the command screen must use only events already received by HQ, not `World.regions.found` or actual agent positions. Show last-known drone position with stale treatment; render local logs/flight trail only in explicit drone-device POV. Keep a visible map legend including river/flooded roads, yellow rescue route, sector boundaries and launch points. Render a red network-down and green resynchronized banner.
5. **CS3 / gateway:** retain any real n8n transport separately; the standalone reference build only simulates command receipt and human approval. The offline command screen must not imply that a new off-grid discovery reached HQ before a link becomes available.

**Do not replace the team's canonical `src/shared/types.ts` unilaterally.** Add the new sector/dispatch/telemetry types after agreeing changes with other contributors. Existing plan ownership and integration tests still apply.

## v6 handoff — mission planning, bounded movement and charge control

This standalone branch has **not** altered the team's shared TypeScript contract. For the team implementation, coordinate schema changes before editing `src/shared/types.ts`.

- **CS1 — scenario/map/sim:** accept an optional exact `rectangle={south,north,west,east}`; compute local projected bounds, generate equal-area rectangular sectors and place initial agents/staging pins outside them. UI drag-to-rectangle should update the scenario *before* simulation starts. Default pins are labelled **unverified**, not imaginary helipads/open fields. Remove the synthetic blue river and strengthen modeled hazard visualization. Basemap tiles do not prove street accessibility or flood damage.
- **CS2 — agents:** use metres per simulated minute; drone cruise is 500 m/min (30 km/h), capped at 833.3 m/min (50 km/h), with slower ground and boat motion. Regional scans take multiple ticks (2.5% coverage/minute by the drone). Add local battery, returning, charging and resume states. Choose nearest staging pad when charge reserve is low. Drone sector crossing is disabled until its own work has completed and a rescue-site handover has been observed; an emergency battery return takes priority over a hold.
- **CS3 — UI/commander:** implement pre-flight drawing with a map corner-to-corner gesture, a separate external-staging pin-placement mode, and local drone telemetry including model-labelled synthetic readings. Preserve HQ data freeze on mast loss; local POV must not accidentally expose live hidden world state to HQ. Rescue approval continues to assign one nearest eligible non-drone responder.
- **Presentation:** demo boundary drawing → external launch placement → start → separate drone flight → battery return/recharge → human-approved rescue → network outage → peer discovery → HQ reconciliation. Mention that physical landing suitability is not verified and sensor readings are synthetic.

**Status:** the browser build is a tested reference. The original PDF's proposed distributed architecture, n8n workflow and Vite/React/TypeScript interfaces still require team integration; do not claim this static local browser is a deployed disaster-response network.

## v7 handoff — revised local POV and outage behavior

- **CS1 (scenario and simulation):** `makeScenario` bounds the number of proposed launch sites by the number of drones; extra operator-chosen sites can be added up to the cap. A site is reserved while a drone is returning or charging. Add the `unregisteredAssignments` population category to the simulator's invariants (separate from the *expected* person count). The generator's locations remain synthetic until verified GIS inputs are supplied.
- **CS2 (agents):** replace terminal `coverage>=99%` exclusion with repeat patrol passes. The world alone decides synthetic discoveries; agents receive local `SURVEY` events with `sightings:[{lat,lng,count}]` coordinates and can replay peer events over their own log. A rescue hold has a small bounded loiter movement, except for battery safety return. Extend heartbeats with `battery`, `flightState`, and `rechargeSite`. Resolve charging reservation competition before selecting a pad.
- **CS3 (UI):** add live **on-device** WGS84 telemetry and aggregate sighting locations, a main-command battery warning panel based strictly on *last received* heartbeats, a large OFFLINE splash with actions, and stale HQ markers while offline. The local POV remains active, even when HQ is frozen.
- **Presentation:** start offline simulation -> mast failure -> enter local POV -> show advancing tick, GPS, and fresh sighting clusters -> return to frozen HQ -> restore -> show command count catching up. Indicate that local simulated telemetry does not reach the command centre while disconnected.

**Contract reminder:** `SURVEY` coordinates and battery heartbeat fields are additions in this runnable reference, not automatically compatible with the team's canonical person-based `FieldEvent` union. Discuss with all three CS contributors before porting into shared types. Do not equate these geolocated clusters with verified physical GPS positions.

## v8 n8n reconnection handoff

- Simulation owner: `World.setMast(true)` creates `lastRecovery` from the set of newly synchronized field events, and `World.recoveryPayload()` produces a bounded fictional training packet.
- UI owner: `showRestored()` displays the non-blocking green recovery splash and attempts n8n forwarding only if an endpoint was explicitly configured. Existing offline POV and red mast-failure splash remain unchanged.
- Gateway/n8n owner: `gateway-server.mjs` provides a local same-origin HTTP relay; `n8n/RESPOND_recovery_workflow.json` demonstrates three branches. Wire each branch to an authorised demo-only recipient. The app displays **accepted by n8n**, never unverified delivery claims.
- Demo script: Start → mast down → demonstrate onboard autonomous updates → mast up → **SYSTEMS BACK ONLINE** card → optionally show n8n's three audience branches receiving the packet.
