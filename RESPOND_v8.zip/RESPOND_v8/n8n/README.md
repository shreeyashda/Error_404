# n8n: mast-restoration notifications

The included workflow is an **importable routing template**, not a configured live alerting service. Its three branches are **COUNCIL**, **RESCUE LEADERS** and **NEWS DESK**. Each ends in a clearly labelled No Operation node so a demo does not accidentally contact real emergency services or media. Replace those three nodes with n8n Email, Slack, Teams, SMS, or authorised webhook connectors, using team-approved **exercise-only** recipients and credentials. Test all branches individually before enabling outbound messages.

## Example: connect the runnable demo to local n8n

1. Run n8n locally (typically `http://localhost:5678`) and import `RESPOND_recovery_workflow.json`.
2. Configure the workflow's Webhook node at path `respond-recovery`. Activate the workflow to use the production path, or use its temporary test path while listening in n8n.
3. Start the optional RESPOND relay in another Windows PowerShell window:

```powershell
$env:RESPOND_N8N_WEBHOOK_URL = 'http://localhost:5678/webhook/respond-recovery'
npm run gateway
```

4. Open `http://localhost:8000` — the app will discover the relay and automatically forward a **single recovered batch** whenever the mast is restored. The app displays **Accepted by n8n** only if the relay receives a successful HTTP status.
5. In n8n, the three No Operation branch nodes show where council, responder leadership and news-outlet notifications would be routed. No real messages leave those branches until you explicitly replace them.

## Important status distinction

- **Demo mode:** the card shows all three audiences, but no external request is made.
- **Forwarding:** an HTTP POST is being attempted.
- **Accepted by n8n:** the configured webhook acknowledged the batch; it does **not** prove the three recipient notifications were delivered.
- **Failure:** reports remain in the browser and can be exported or retried.

`POST /api/recovery` only accepts `{schema:'respond.recovery.v1',trainingOnly:true}`. Packets include area, flood stage, region-level counts, simulated road closures, and a bounded sample of independently captured field observations. All people are fictional. For a real deployment, authenticate the gateway, use TLS, enforce idempotency using `batchId`, secure audit logs, verify all recipients, and require trained human approval for public notifications.
