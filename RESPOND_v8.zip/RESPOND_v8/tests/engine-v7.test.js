import test from 'node:test';
import assert from 'node:assert/strict';
import {World,makeScenario,metres} from '../src/engine.js';

test('launch site count never exceeds drone count and zero drones has no pads',()=>{
 for(const n of [0,1,2,3,4,10]){
  const s=makeScenario({drones:n,responders:3});
  assert.ok(s.launchSites.length<=n, `${n} drones, ${s.launchSites.length} sites`);
  assert.equal(s.teams.filter(t=>t.vehicle==='drone').length,n);
 }
});
test('custom additional staging pads can be added only up to the drone count',()=>{
 const s=makeScenario({drones:5,launchSites:[{id:'site-5',name:'Operator chosen',pos:{lat:27.72,lng:85.34}}]});
 assert.equal(s.launchSites.length,5);
 assert.equal(s.launchSites[4].id,'site-5');
 const extra=makeScenario({drones:1,launchSites:[{id:'site-5',pos:{lat:27.72,lng:85.34}}]});
 assert.equal(extra.launchSites.length,1);
});
test('unregistered residents are explicitly assigned to regions and discovered on repeated scans',()=>{
 const w=new World(makeScenario({people:4000,drones:1,responders:0}));
 assert.equal(w.populationValid(),true);
 const a=w.getAgent('drone-1'),r=w.regions.find(reg=>reg.unexpected>0);
 assert.ok(r);
 a.pos={...r.pos};a.target=r.id;
 for(let i=0;i<115;i++){w.tick++;w.searchRegion(a,r);}
 assert.ok(r.found>r.expected,`found ${r.found}, expected ${r.expected}, hidden ${r.unexpected}`);
 assert.equal(w.populationValid(),true);
 const sight=a.history.filter(e=>e.type==='SURVEY'&&e.sightings?.length);
 assert.ok(sight.length>0);
 assert.ok(sight.every(e=>e.sightings.every(pt=>Number.isFinite(pt.lat)&&Number.isFinite(pt.lng)&&pt.count>0)));
});
test('drone never completely exhausts its task pool after initial surveys',()=>{
 const w=new World(makeScenario({people:80,drones:1,responders:0,regionCount:2}));
 const a=w.getAgent('drone-1');
 // Report a first sweep for each region; keep rescue reports settled.
 for(const region of a.visibleRegions.values()){
  a.append(1,'SURVEY',{region:region.id,amount:1,found:region.expected});
 }
 const next=a.choose(100,w.teams,w.scenario.terrain,w.scenario.center);
 assert.ok(next,'must revisit a zone to search for missed/unregistered residents');
});
test('unoccupied pad reserved to nearest eligible low-charge drone',()=>{
 const w=new World(makeScenario({drones:2,responders:1}));
 const a=w.getAgent('drone-1'),b=w.getAgent('drone-2');
 a.battery=22;b.battery=22;
 a.pos={...w.scenario.launchSites[0].pos};b.pos={...w.scenario.launchSites[0].pos};
 w.step();
 assert.notEqual(a.rechargeSite,b.rechargeSite);
 assert.ok(['returning','charging'].includes(a.flightState));
 assert.ok(['returning','charging'].includes(b.flightState));
});
test('HQ battery warnings can only use received heartbeats during mast loss',()=>{
 const w=new World(makeScenario({drones:1,responders:1})),a=w.getAgent('drone-1');
 for(let i=0;i<8;i++)w.step();
 const original=w.commandView().lastSeen.get(a.id)?.battery;
 assert.ok(Number.isFinite(original));
 w.setMast(false);a.battery=21;
 for(let i=0;i<12;i++)w.step();
 assert.equal(w.commandView().lastSeen.get(a.id)?.battery,original);
 w.setMast(true);for(let i=0;i<4;i++)w.step();
 assert.notEqual(w.commandView().lastSeen.get(a.id)?.battery,original);
});
test('rescue loiter maintains motion near site without crossing sector boundary',()=>{
 const w=new World(makeScenario({people:500,drones:1,responders:0})),a=w.getAgent('drone-1');
 const r=w.regions.find(r=>r.sector===a.sector);
 a.waitingRescue=true;a.target=r.id;a.pos={...r.pos};
 for(let i=0;i<5;i++)w.step();
 assert.equal(a.flightState,'holding-for-rescue');
 assert.ok(a.distanceM>0);
 assert.ok(metres(a.pos,r.pos)<100);
});
