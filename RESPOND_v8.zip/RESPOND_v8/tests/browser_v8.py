from pathlib import Path
from playwright.sync_api import sync_playwright
root=Path(__file__).resolve().parents[1]
with sync_playwright() as p:
 b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=b.new_page(viewport={'width':1350,'height':980},device_scale_factor=1)
 errors=[]
 page.on('pageerror',lambda error: errors.append(str(error)))
 page.set_content((root/'standalone.html').read_text(),wait_until='domcontentloaded')
 page.evaluate('window.RESPOND.configure({people:400,drones:3,responders:4})')
 for _ in range(12):page.evaluate('window.RESPOND.step()')
 page.evaluate('window.RESPOND.setMast(false)')
 assert page.locator('#offlineSplash').is_visible()
 page.locator('#offlineToPOV').click()
 assert page.locator('#droneView').is_visible()
 for _ in range(35):page.evaluate('window.RESPOND.step()')
 old=page.evaluate('window.RESPOND.world.commandView().reported')
 page.evaluate('window.RESPOND.setMast(true)')
 assert page.locator('#recoverySplash').is_visible()
 assert not page.locator('#offlineSplash').is_visible()
 assert page.locator('#recoverySplash').inner_text().count('SYSTEMS BACK ONLINE')==1
 assert 'SIMULATION ONLY' in page.locator('#recoveryDelivery').inner_text()
 assert page.evaluate('window.RESPOND.world.commandView().reported')>=old
 assert page.evaluate('window.RESPOND.world.recoveryPayload().recipients.length')==3
 page.locator('#recoveryClose').click()
 assert page.locator('#recoverySplash').is_hidden()
 page.locator('#tabCommand').click()
 page.evaluate('window.RESPOND.setMast(false)')
 page.locator('#offlineToHQ').click()
 for _ in range(8):page.evaluate('window.RESPOND.step()')
 page.evaluate('window.RESPOND.setMast(true)')
 assert page.locator('#recoverySplash').is_visible()
 page.screenshot(path=str(root/'RESPOND_v8_recovered.png'),full_page=True)
 print('Browser v8 PASS: offline, local POV, recovery card, demo-only n8n, dismiss, repeat outage')
 assert not errors,errors
 b.close()
