import test from 'node:test';
import assert from 'node:assert/strict';
import {World,makeScenario,metres,outsideBounds,createSectors,MAX_DRONE_METRES_PER_TICK} from '../src/engine.js';

test('rectangular pre-flight mission preserves exact geographic bounds and equal sectors',()=>{
 const rectangle={south:27.681,north:27.693,west:85.293,east:85.315};
 const s=makeScenario({rectangle,drones:4,people:4000});
 assert.deepEqual(s.rectangle,rectangle);
 assert.equal(s.sectors.length,4);
 assert.ok(s.regions.every(r=>r.sector));
 assert.ok(s.regions.every(r=>!outsideBounds(r.pos,s.center,s.bounds)));
 assert.ok(s.sectors.every(z=>Math.abs(z.areaKm2-s.bounds.areaKm2/4)<1e-8));
 assert.equal(new World(s).populationValid(),true);
});

test('all drones and rescuers start outside mission boundary',()=>{
 for(const count of [1,4,11]){
  const s=makeScenario({drones:count,responders:12});
  assert.ok(s.teams.every(t=>outsideBounds(t.start,s.center,s.bounds)));
  assert.ok(s.launchSites.every(t=>outsideBounds(t.pos,s.center,s.bounds)));
 }
});

test('operator-selected staging coordinates are preserved when outside the box',()=>{
 const one=makeScenario({drones:4,launchSites:[{id:'field',name:'Selected landable location, verify',pos:{lat:27.72,lng:85.34}}]});
 assert.deepEqual(one.launchSites.find(x=>x.id==='field').pos,{lat:27.72,lng:85.34});
 const two=makeScenario({drones:4,launchSites:[{id:'field',name:'Invalid inside',pos:one.center}]});
 assert.ok(outsideBounds(two.launchSites.find(x=>x.id==='field').pos,two.center,two.bounds));
});

test('drone sector assignment is one-to-one and priority is nearest launch-sector pairs',()=>{
 const s=makeScenario({drones:4,responders:7});
 const drones=s.teams.filter(t=>t.vehicle==='drone');
 assert.equal(new Set(drones.map(t=>t.sector)).size,4);
 assert.equal(new Set(s.sectors.map(t=>t.id)).size,4);
});

test('drone hard speed limit is at most 50 km/h and faster than dispatch transit',()=>{
 const w=new World(makeScenario({drones:3,responders:9}));
 assert.ok(MAX_DRONE_METRES_PER_TICK<=833.33334);
 for(let i=0;i<50;i++){w.step();assert.ok(w.agents.filter(x=>x.vehicle==='drone').every(x=>x.speedMPerTick<=MAX_DRONE_METRES_PER_TICK+.0001));}
 const drone=w.getAgent('drone-1'),car=w.getAgent('responder-1');
 const destination={lat:drone.pos.lat+.003,lng:drone.pos.lng+.005};
 car.pos={...drone.pos};w.travel(drone,{pos:destination});w.travel(car,{pos:destination});
 assert.ok(drone.speedMPerTick>car.speedMPerTick);
 assert.ok(drone.speedMPerTick<=MAX_DRONE_METRES_PER_TICK+.0001);
});

test('battery reserve forces drone to nearest staging site, recharge, then resume',()=>{
 const w=new World(makeScenario({drones:2,responders:2}));
 const a=w.getAgent('drone-1');
 a.battery=21; a.pos={...w.scenario.launchSites[1].pos};
 w.step();
 assert.equal(a.rechargeSite,w.scenario.launchSites[1].id);
 assert.ok(['returning','charging'].includes(a.flightState));
 for(let i=0;i<45;i++)w.step();
 assert.ok(a.battery>21);
 assert.ok(a.flightState!=='returning');
});

test('drone will not abandon its sector while rescue remains outstanding',()=>{
 const w=new World(makeScenario({drones:3,responders:6}));
 const a=w.getAgent('drone-1');
 a.handoverCleared=false;
 const result=a.choose(30,w.teams.map(t=>({id:t.id,vehicle:t.vehicle,sector:t.sector})),w.scenario.terrain,w.scenario.center);
 assert.ok(result);
 assert.equal(a.visibleRegions.get(result).sector,a.sector);
});

test('no modelled blue river is needed for flood risk or routing',()=>{
 const s=makeScenario({drones:4});
 const w=new World(s);w.flood(3);
 assert.ok(w.graph.edges.some(e=>w.actualRoads.get(e.id)==='boat_only'));
});
