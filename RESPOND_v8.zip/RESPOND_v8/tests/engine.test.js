import test from 'node:test';
import assert from 'node:assert/strict';
import {makeScenario,World,route,PRESETS,metres,createSectors,searchBounds,sectorOf} from '../src/engine.js';

test('population scales to 50,000 with exactly one region per individual',()=>{
 for (const n of [1,400,20000,50000]) {
  const scenario=makeScenario({seed:32,people:n,drones:5,responders:8});
  const world=new World(scenario);
  assert.equal(scenario.assignments.length,n);
  assert.equal(world.expected(),n);
  assert.equal(world.populationValid(),true);
  assert.ok(world.regions.length<60);
  assert.ok(world.regions.every(r=>r.expected>=0));
 }
});

test('reproducible organic positions and high-density clustering',()=>{
 const a=makeScenario({seed:123,people:50000,drones:8,responders:20});
 const b=makeScenario({seed:123,people:50000,drones:8,responders:20});
 assert.deepEqual(a.regions.map(r=>[r.pos,r.expected,r.rawRisk]),b.regions.map(r=>[r.pos,r.expected,r.rawRisk]));
 assert.equal(a.teams.length,28);
 assert.notEqual(a.regions[0].pos.lng,a.regions[1].pos.lng);
 assert.ok(Math.max(...a.regions.map(r=>r.expected))>Math.min(...a.regions.map(r=>r.expected))*2);
});

test('agents have local beliefs only, and advance during mast failure',()=>{
 const w=new World(makeScenario({seed:33,people:800,drones:3,responders:7}));
 const drone=w.getAgent('drone-1');
 assert.equal('atRisk' in [...drone.visibleRegions.values()][0],false);
 assert.equal('assignments' in drone,false);
 w.setMast(false);
 for(let i=0;i<30;i++)w.step();
 assert.ok(w.simSummary().found>0);
 assert.equal(w.simSummary().reported,0);
 assert.ok(w.agents.some(a=>a.q.some(v=>v>0)));
 assert.ok(w.agents.some(a=>a.visits>0));
 w.setMast(true);for(let i=0;i<6;i++)w.step();
 assert.ok(w.simSummary().reported>0);
});

test('agent logs converge by idempotent peer merge',()=>{
 const w=new World(makeScenario({people:100,drones:2}));
 const a=w.getAgent('drone-1'),b=w.getAgent('drone-2');
 a.append(1,'SURVEY',{region:'R01',amount:.1,found:2});
 b.append(2,'SURVEY',{region:'R01',amount:.1,found:1});
 a.merge(b);b.merge(a);a.merge(b);b.merge(a);
 assert.equal(a.log.size,2);assert.equal(b.log.size,2);
 assert.equal(a.progress.get('R01'),.2);assert.equal(b.knownFound.get('R01'),3);
});

test('manual search area added while offline is eventually synchronized and people remain assigned',()=>{
 const w=new World(makeScenario({people:100,drones:2}));
 w.setMast(false);const region=w.addSearchRegion({lat:27.688,lng:85.311,name:'Bridge approach',expected:15});
 assert.equal(w.expected(),115);assert.equal(w.populationValid(),true);
 assert.equal(w.getAgent('drone-1').visibleRegions.has(region.id),false);
 for(let i=0;i<8;i++)w.step();assert.equal(w.populationValid(),true);
 w.setMast(true);for(let i=0;i<4;i++)w.step();
 assert.equal(w.getAgent('drone-1').visibleRegions.has(region.id),true);
});

test('changing target geography changes mission coordinates',()=>{
 const k=makeScenario({area:'kathmandu'}),c=makeScenario({area:'carlisle'});
 assert.equal(k.center.lat,PRESETS.kathmandu.lat);
 assert.equal(c.center.lat,PRESETS.carlisle.lat);
 assert.ok(metres(k.regions[0].pos,c.regions[0].pos)>100000);
});

test('floods remove car access but maintain boat routes where possible',()=>{
 const w=new World(makeScenario({people:1000}));
 w.flood(3);
 assert.ok([...w.actualRoads.values()].some(s=>s==='boat_only'));
 const routes=w.regions.map(r=>w.routeOptions(r.id));
 assert.ok(routes.some(options=>options[0].route===null&&options[1].route!==null));
});

test('civilian relocations preserve all 50,000 region assignments',()=>{
 const w=new World(makeScenario({seed:101,people:50000,responders:15,drones:10}));
 for(let i=0;i<90;i++)w.step();
 assert.equal(w.populationValid(),true);
 assert.equal(w.regions.reduce((x,r)=>x+r.present,0),50000);
 assert.equal(w.simSummary().expected,50000);
});

test('commander dispatch needs explicit approval',()=>{
 const w=new World(makeScenario({people:2500,drones:4}));
 for(let i=0;i<80;i++)w.step();
 assert.ok(w.recommendations.length>0);
 assert.equal(w.approved.length,0);
 const rec=w.recommendations[0];
 assert.equal(w.approve(rec.id,'approved'),true);
 assert.equal(w.approved.length,1);
});

test('lost drone recovery happens after surviving drones have had responders reach their held zones',()=>{
 const w=new World(makeScenario({people:50000,drones:4,responders:8}));
 for(let i=0;i<12;i++)w.step();w.ground('drone-1');
 let taken=false;
 for(let i=0;i<900;i++){
  w.step();
  for(const rec of w.recommendations.filter(r=>r.status==='pending'))w.approve(rec.id,'approved');
  taken ||= w.agents.some(a=>a.vehicle==='drone'&&!a.down&&a.takeover);
 }
 assert.equal(taken,true);
 assert.equal(w.getAgent('drone-1').down,true);
});

test('square/rectangular mission has exactly N equal-area drone sectors, all residents belong to a region',()=>{
 for(const drones of [1,2,3,4,5,7,12,20]){
  const s=makeScenario({people:50000,drones,responders:5});
  assert.equal(s.sectors.length,drones);
  assert.ok(s.regions.every(r=>r.sector));
  const total=s.sectors.reduce((a,x)=>a+x.areaKm2,0);
  assert.ok(Math.abs(total-s.bounds.areaKm2)<1e-8);
  for(const sector of s.sectors)assert.ok(Math.abs(sector.areaKm2-total/drones)<1e-8);
  assert.ok(s.sectors.every(sec=>sectorOf(sec.center,s.center,s.sectors)===sec.id));
  assert.equal(new World(s).populationValid(),true);
 }
});

test('mission square kilometres grows proportionally with the number of drones',()=>{
 const two=makeScenario({drones:2,people:100}).bounds.areaKm2;
 const four=makeScenario({drones:4,people:100}).bounds.areaKm2;
 const eight=makeScenario({drones:8,people:100}).bounds.areaKm2;
 assert.ok(Math.abs(four/two-2)<1e-6);
 assert.ok(Math.abs(eight/four-2)<1e-6);
});

test('launch configurations share fixed staging sites rather than random drone positions',()=>{
 const a=makeScenario({drones:6,launchMode:'school'});
 const starts=a.teams.filter(t=>t.vehicle==='drone');
 assert.equal(new Set(starts.map(t=>t.launchSite)).size,1);
 assert.ok(starts.every(t=>t.launchSite==='school'));
 assert.equal(new Set(starts.map(t=>JSON.stringify(t.start))).size,1);
 const b=makeScenario({drones:6,launchMode:'distributed'});
 assert.ok(new Set(b.teams.filter(t=>t.vehicle==='drone').map(t=>t.launchSite)).size>1);
});

test('HQ counter freezes during mast failure then catches up from drone local logs',()=>{
 const w=new World(makeScenario({seed:45,people:1500,drones:4,responders:3}));
 for(let i=0;i<7;i++)w.step();
 const before=w.commandView().reported;
 w.setMast(false);
 for(let i=0;i<35;i++)w.step();
 assert.equal(w.commandView().reported,before);
 assert.ok(w.simSummary().found>=before);
 assert.ok(w.agents.some(a=>a.distanceM>0));
 w.setMast(true);assert.ok(w.commandView().reported>=before);
 assert.equal(w.commandView().reported,w.simSummary().reported);
});

test('a rescue dispatch assigns at most one nearest eligible non-drone responder, with human approval',()=>{
 const w=new World(makeScenario({seed:42,people:2500,drones:4,responders:8}));
 for(let i=0;i<50;i++)w.step();
 assert.ok(w.recommendations.length);
 const rec=w.recommendations.find(r=>r.status==='pending');
 const expected=w.nearestResponder(rec.region)?.agent.id;
 assert.ok(expected);
 assert.equal(w.agents.filter(a=>a.dispatchJob).length,0);
 w.approve(rec.id,'approved');
 assert.equal(w.agents.filter(a=>a.dispatchJob).length,1);
 assert.equal(w.agents.find(a=>a.dispatchJob)?.id,expected);
 assert.ok(w.agents.filter(a=>a.vehicle==='drone').every(a=>!a.dispatchJob));
});

test('dispatch approval while mast is down queues until link restored',()=>{
 const w=new World(makeScenario({seed:57,people:1200,drones:4,responders:7}));
 for(let i=0;i<45;i++)w.step();
 const rec=w.recommendations.find(r=>r.status==='pending');assert.ok(rec);
 w.setMast(false);w.approve(rec.id,'approved');
 assert.equal(w.agents.filter(a=>a.dispatchJob).length,0);
 assert.equal(rec.status,'queued');
 w.setMast(true);w.step();assert.equal(rec.status,'approved');
 assert.equal(w.agents.filter(a=>a.dispatchJob).length,1);
});

test('drone finishes a zone once 99% of expected residents are located but waits for rescue arrival',()=>{
 const w=new World(makeScenario({people:400,drones:1,responders:6}));
 const a=w.getAgent('drone-1');
 const reg=w.regions.filter(r=>r.sector===a.sector&&r.expected>0)[0];
 a.target=reg.id;a.pos={...reg.pos};
 for(let i=0;i<85;i++){w.tick++;w.searchRegion(a,reg);}
 assert.ok(reg.found>=Math.ceil(.99*reg.expected));
 if(reg.atRisk>0){assert.equal(a.waitingRescue,true);assert.equal(a.target,reg.id);}
 const rec=w.recommendations.find(r=>r.region===reg.id);
 if(rec){w.approve(rec.id,'approved');for(let i=0;i<190;i++){w.step();if(reg.responderArrived)break;}assert.equal(reg.responderArrived,true);assert.equal(a.waitingRescue,false);}
});
