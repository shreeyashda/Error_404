from pathlib import Path
from playwright.sync_api import sync_playwright
source=Path(__file__).resolve().parents[1]
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':1420,'height':1000})
    errors=[]
    page.on('pageerror',lambda err:errors.append(str(err)))
    page.set_content((source/'standalone.html').read_text(),wait_until='domcontentloaded')
    assert page.locator('#stats').count()==1
    page.evaluate('window.RESPOND.configure({drones:2,people:1500})')
    assert page.evaluate('window.RESPOND.scenario.launchSites.length')<=2
    page.evaluate('window.RESPOND.step()')
    page.evaluate('window.RESPOND.setMast(false)')
    assert page.locator('#offlineSplash').is_visible()
    page.locator('#offlineToPOV').click()
    assert page.locator('#droneView').is_visible()
    before=page.evaluate('window.RESPOND.world.tick')
    page.evaluate('window.RESPOND.step()')
    assert page.evaluate('window.RESPOND.world.tick')==before+1
    assert page.locator('.coordTile').is_visible()
    assert 'OFFLINE' in page.locator('#sensorStamp').inner_text()
    page.evaluate('window.RESPOND.setMast(true)')
    assert not page.locator('#offlineSplash').is_visible()
    assert not errors,errors
    print('Browser smoke test PASS: offline splash, live local POV, coordinates, reconnect')
    browser.close()
