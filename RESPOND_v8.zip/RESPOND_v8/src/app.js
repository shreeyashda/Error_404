import {World,makeScenario,importOverpass,route,PRESETS,clamp,metres,metersToLL,searchBounds,outsideBounds,rng,MAX_DRONE_METRES_PER_TICK} from './engine.js';

const $=id=>document.getElementById(id);
const fmt=n=>Number(n||0).toLocaleString('en-GB');
const esc=x=>String(x).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let config={seed:2024,people:400,drones:4,responders:7,area:'kathmandu',span:3.5,launchMode:'distributed'};
let world,baseline,scenario,roadData=null,playing=false,speed=3,tab='command',view='street',overlay=true;
let selectedRegion=null,selectedTeam=null,interaction='inspect',showStarts=true,showResponders=false;
let requestedLaunchSite='command',drawStart=null; // pre-flight cartography, no backend dependency
let zoom=15,mapCenter,dragging=null,didDrag=false,frame=0,tilesKey='',oldReported=0;
let n8nEndpoint='',gatewayReady=false,recoveryView=null,recoveryDismissTimer=null,lastForwardedBatchId='';
const W=1080,H=690;
const project=(point,z=zoom)=>{const f=2**z*256,r=point.lat*Math.PI/180;return{x:(point.lng+180)/360*f,y:(1-Math.log(Math.tan(r)+1/Math.cos(r))/Math.PI)/2*f};};
const unproject=(x,y,z=zoom)=>{const f=2**z*256,n=Math.PI-2*Math.PI*y/f;return{lat:180/Math.PI*Math.atan(Math.sinh(n)),lng:x/f*360-180};};
const xy=p=>{const a=project(p),b=project(mapCenter);return{x:a.x-b.x+W/2,y:a.y-b.y+H/2};};
const ll=(x,y)=>{const c=project(mapCenter);return unproject(c.x+x-W/2,c.y+y-H/2);};
const path=pts=>pts.map((p,i)=>{const q=xy(p);return`${i?'L':'M'}${q.x.toFixed(1)} ${q.y.toFixed(1)}`;}).join(' ');
const boxPoints=(bounds)=>[
 metersToLL(scenario.center,bounds.minX,bounds.minY),metersToLL(scenario.center,bounds.maxX,bounds.minY),
 metersToLL(scenario.center,bounds.maxX,bounds.maxY),metersToLL(scenario.center,bounds.minX,bounds.maxY)
];
function fitMissionZoom(){const pts=boxPoints(scenario.bounds).concat(scenario.launchSites.map(s=>s.pos));for(let z=17;z>=10;z--){const all=pts.map(p=>project(p,z)),xx=all.map(p=>p.x),yy=all.map(p=>p.y);if(Math.max(...xx)-Math.min(...xx)<=W*.86&&Math.max(...yy)-Math.min(...yy)<=H*.78)return z;}return 10;}
function initialize(){scenario=makeScenario({...config,roadData});world=new World(scenario);baseline=new World(makeScenario({...config,roadData}),'central');selectedRegion=null;selectedTeam=scenario.teams.find(t=>t.vehicle==='drone')?.id||null;mapCenter={...scenario.center};zoom=fitMissionZoom();tilesKey='';playing=false;oldReported=0;}
function mount(){initialize();$('app').innerHTML=`
<header class="nav"><div class="logo"><span class="logoicon">✳</span><span>RESPOND<small>REGIONAL EMERGENCY SURVEILLANCE PINPOINTING OBJECTIVES IN NATURAL DISASTERS</small></span></div><div class="navright">FIELD OPERATIONS <span class="separator">/</span> NO REAL EMERGENCY DISPATCH</div></header>
<main class="shell">
 <div class="head"><div><div class="overline">RESPOND COMMAND <span id="clock">T+000</span></div><h1>Search continues without a signal.</h1><div class="subtitle" id="locationName"></div></div><div class="head-actions"><span id="network" class="network">● MAST ONLINE</span><button id="n8nBtn" class="outline">⚡ n8n gateway</button><button id="scenarioBtn" class="outline">⚙ Configure mission</button></div></div>
 <div id="outageBanner" class="outageBanner" hidden></div>
 <div id="recoverySplash" class="recoverySplash" hidden role="status" aria-live="polite">
  <div class="recoveryTop"><span class="recoveryCheck">✓</span><div><strong>SYSTEMS BACK ONLINE</strong><small>Network restored · offline observations synchronized</small></div><button id="recoveryClose" class="recoveryClose" aria-label="Dismiss recovery notification">×</button></div>
  <p id="recoverySummary"></p>
  <div class="recoveryTargets"><span>🏛 Council incident desks</span><span>🛟 Rescue team leaders</span><span>◉ News outlets</span></div>
  <div class="recoveryDelivery" id="recoveryDelivery"></div>
  <div class="recoveryFooter"><small>Fictional training data only — real recipients require a configured n8n workflow.</small><button id="recoveryDownload" class="smallbtn">Export n8n packet</button></div>
 </div>
 <div class="preflight" id="preflight"><span><b>PRE-FLIGHT PLANNING</b><small>Draw a rectangle; place up to one external launch point per drone. The browser cannot verify site safety.</small></span><button id="drawMission" class="outline">▱ Draw search rectangle</button><button id="planLaunch" class="outline">△ Choose launch point</button></div>
 <div class="tabs"><button class="tab active" id="tabCommand">▣ Incident overview</button><button class="tab" id="tabDrone">⌁ Drone flight & local POV</button><span class="tabnote">One simulated minute per tick</span></div>
 <section class="stats" id="stats"></section>
 <section id="commandView" class="workspace"><div class="mapcard"><div class="maptop"><div><b>Search-area map</b><span id="mapSource"></span></div><div class="mapfilters"><button class="chip active" data-view="street">Streets</button><button class="chip" data-view="topo">Terrain</button><button class="chip" data-view="model">Offline</button><button id="riskBtn" class="chip active">Threat</button><button id="launchBtn" class="chip active">Launch sites</button><button id="allTeamsBtn" class="chip">Ground units</button></div></div>
 <div id="mapouter" class="mapouter"><svg id="map" viewBox="0 0 ${W} ${H}" aria-label="Map with rectangular mission zones"><g id="mapBase"></g><g id="mapLive"></g><g id="drawPreview" pointer-events="none"></g></svg><div class="maptools"><button id="zoomIn">+</button><button id="zoomOut">−</button><button id="recenter">⌖</button></div><div class="mapcaps"><span id="mapGeometry"></span><span id="mapHint">Drag to pan · select a search zone</span></div><div class="mapcredits">Map © OpenStreetMap / OpenTopoMap · simulated flood data</div></div>
 <div class="mapfoot"><div class="legend"><span><i class="red"></i>High risk</span><span><i class="amber"></i>Needs search</span><span><i class="green"></i>Located</span><span><i class="blue"></i>Boat-only road (if flooded)</span><span><i style="background:#fbd47b"></i>Rescue route</span><span>□ Drone sector</span><span>△ Launch site</span></div><div class="map-foot-actions"><button id="addSearch" class="smallbtn">+ Add search zone</button><button id="useView" class="smallbtn">Set mission here</button></div></div></div>
 <aside class="sidebar"><div class="panel"><div class="section-top"><span>COMMANDER ACTION</span><span class="tag">APPROVAL REQUIRED</span></div><div id="actionCard"></div></div><div class="panel"><div class="section-top"><span>REGIONAL SEARCH</span><span id="taskCount" class="tag"></span></div><div class="scrolllist" id="regionsList"></div></div><div class="panel"><div class="section-top"><span>RESPONDER MONITOR</span><button id="teamExpand" class="textbtn">All units</button></div><div id="batteryAlerts"></div><div id="responderList" class="scrolllist"></div></div></aside></section>
 <section id="droneView" class="droneWorkspace" hidden><div class="mapcard"><div class="maptop"><div><b>Simulated drone sensor and flight log</b><span>This is the drone's LOCAL knowledge, not a camera feed or live HQ telemetry</span></div><div class="mapfilters"><label class="droneSelectLabel">Drone <select id="droneSelect"></select></label></div></div><div class="droneRadar"><svg id="droneMap" viewBox="0 0 950 570"></svg><span class="sensorStamp" id="sensorStamp"></span></div><div class="mapfoot"><div class="legend"><span><i class="green"></i>Observed residents</span><span><i class="amber"></i>Incomplete search</span><span>━━ Flight path</span><span>▱ Assigned sector</span></div></div></div><aside class="sidebar"><div class="panel"><div class="section-top"><span>LIVE LOCAL TELEMETRY</span><span class="tag">ON-DEVICE ONLY</span></div><div id="droneTelemetry"></div></div><div class="panel"><div class="section-top"><span>LOCAL DECISIONS</span><span class="tag">AUTONOMOUS</span></div><div id="droneDecisions"></div><div id="sensorLog" class="sensorLog"></div><div id="droneSightings" class="sightingPanel"></div></div><div class="panel"><div class="section-top"><span>FLIGHT CONTROL</span></div><div id="droneControl"></div></div></aside></section>
 <section class="below"><div class="panel control"><div class="section-top"><span>SIMULATION CONTROL</span><span id="simTime">MODELLING ONLY</span></div><div class="buttons"><button id="play" class="primary">▶ Start</button><button id="step" class="outline">Step</button><button id="mast" class="danger">✕ Mast failure</button><button id="reset" class="outline">↻ Reset</button><button id="compare" class="outline">Compare systems</button><label>Speed <select id="speed"><option value="1">1×</option><option value="3" selected>3×</option><option value="8">8×</option><option value="16">16×</option></select></label></div><div class="flood-row"><label>FLOOD STAGE <b id="waterText">Normal</b></label><input type="range" id="water" min="0" max="3" value="0" step="1"><span>Normal</span><span>Rising</span><span>Severe</span><span>Critical</span></div></div><div class="panel"><div class="section-top"><span>FIELD REPORTS</span><button id="export" class="textbtn">Export simulated report ↓</button></div><div id="feed"></div></div></section>
 <footer>Training simulation only. All people, floodwater, access times and routes are synthetic unless explicitly labelled as imported OpenStreetMap geometry. No real drone or emergency service is connected.</footer>
 </main><div id="offlineSplash" class="offlineSplash" hidden role="alertdialog" aria-modal="true" aria-labelledby="offlineTitle"><div class="offlineSplashContent"><div class="offlineSignal">⌁</div><div class="offlineEyebrow">NETWORK FAILURE DETECTED</div><h2 id="offlineTitle">OFFLINE</h2><p>Command has lost live telemetry. Drones are still surveying locally and can exchange discoveries by short-range peer radio.</p><div class="offlineChoices"><button id="offlineToPOV" class="primary">View a live local drone</button><button id="offlineToHQ" class="outline">Continue with stale HQ view</button></div><small>Flight operations continue in the simulation · command counts update after reconnection</small></div></div><dialog id="dialog"><div id="dialogBody"></div></dialog><div id="toast"></div>`;
 bind();render();}
function tileLayer(){if(view==='model')return '';
 const c=project(mapCenter),left=c.x-W/2,top=c.y-H/2,z=zoom,tiles=[];
 for(let tx=Math.floor(left/256);tx<=Math.floor((left+W)/256);tx++)for(let ty=Math.floor(top/256);ty<=Math.floor((top+H)/256);ty++){
  if(ty<0||ty>=2**z)continue;
  const server=view==='topo'?'https://a.tile.opentopomap.org':'https://tile.openstreetmap.org';
  tiles.push(`<image x="${tx*256-left}" y="${ty*256-top}" width="256" height="256" href="${server}/${z}/${tx}/${ty}.png" opacity=".93"/>`);
 }
 return tiles.join('');}
function blobPath(p,radius,shape){const points=[],rx=Math.max(19,Math.abs(project(metersToLL(p,radius,0)).x-project(p).x)*.65),ry=rx*.72;
 const center=xy(p);for(let i=0;i<20;i++){const t=i*2*Math.PI/20,wig=1+.12*Math.sin(t*4+shape*.01)+.07*Math.cos(t*7+shape*.019);
  points.push(`${i?'L':'M'}${(center.x+Math.cos(t)*rx*wig).toFixed(1)} ${(center.y+Math.sin(t)*ry*wig).toFixed(1)}`);
 }return points.join(' ')+'Z';}
const threat=r=>clamp(r.rawRisk*(.70+world.floodLevel*.17)+(r.manual?.12:0),0,1);
const riskColor=r=>threat(r)>.72?'#e76c62':threat(r)>.44?'#edb160':'#deb976';
function displayFor(r,command){const found=command.locatedByRegion.get(r.id)||0,coverage=command.coverageByRegion.get(r.id)||0;
 return{found,coverage,color:found>=Math.ceil(.99*r.expected)&&r.expected>0?'#2cae7c':riskColor(r)};}
function drawMap(){const svg=$('map');if(!svg)return;const key=`${view}:${zoom}:${mapCenter.lat.toFixed(7)}:${mapCenter.lng.toFixed(7)}`;
 if(key!==tilesKey){$('mapBase').innerHTML=`<rect width="${W}" height="${H}" fill="${view==='model'?'#1a363d':'#dbe2da'}"/>${tileLayer()}`;tilesKey=key;}
 const cmd=world.commandView(),offline=!world.mastUp;
 let body='<defs><filter id="hazardBlur"><feGaussianBlur stdDeviation="10"/></filter></defs>';
 // A rectangular search perimeter; N exactly equal-area rectangular drone sectors.
 const corners=boxPoints(scenario.bounds),border=path(corners)+' Z';
 body+=`<path d="${border}" fill="#318998" fill-opacity=".065" stroke="#f1faf2" stroke-width="3" stroke-dasharray="10 6"/>`;
 for(const s of scenario.sectors){const b=boxPoints(s),p=xy(s.center);body+=`<path d="${path(b)} Z" fill="#49bda1" fill-opacity=".055" stroke="#288f87" stroke-width="1.8" stroke-dasharray="7 6"/><g pointer-events="none"><rect x="${p.x-19}" y="${p.y-11}" width="38" height="22" rx="7" fill="#143840" opacity=".83"/><text x="${p.x}" y="${p.y+4}" text-anchor="middle" font-size="11" fill="#d3fff1">${s.id}</text></g>`;}
 // Modelled flood-risk patches; blue river geometry intentionally removed.
 if(overlay)for(const hot of scenario.terrain.hotspots){const p=xy(hot),rp=Math.abs(project(metersToLL(hot,hot.radius,0)).x-project(hot).x);
  body+=`<ellipse cx="${p.x}" cy="${p.y}" rx="${rp*1.45}" ry="${rp}" fill="#ce654e" opacity="${.30+world.floodLevel*.09}" filter="url(#hazardBlur)"/>`;}
 // No synthetic river line. Street / topo layers supply context when network tiles load.
 // Road closures only; normal roads supplied by stable OSM imagery where available.
 for(const edge of world.graph.edges){const st=world.actualRoads.get(edge.id);if(st==='open'&&view!=='model')continue;body+=`<path d="${path(edge.path)}" fill="none" stroke="${st==='blocked'?'#e75c5b':st==='boat_only'?'#3f8fde':'#729b94'}" opacity="${st==='open'?.31:.84}" stroke-width="${st==='open'?1.2:3}" ${st==='open'?'':'stroke-dasharray="5 4"'}/>`;}
 for(const r of world.regions){const p=xy(r.pos);if(p.x < -130||p.x>W+130||p.y < -130||p.y>H+130)continue;
  const state=displayFor(r,cmd),selected=selectedRegion===r.id,d=blobPath(r.pos,r.radius,r.shape),color=state.color;
  body+=`<path d="${d}" fill="${color}" fill-opacity="${offline?.29:.56}" stroke="${selected?'#ffffd5':color}" stroke-width="${selected?4:2.4}" stroke-opacity="${offline?.4:.7}"/><path d="${d}" fill="transparent" stroke="transparent" data-region="${esc(r.id)}" style="cursor:pointer"/>`;
  if(selected||state.found>0||r.manual){body+=`<g pointer-events="none"><rect x="${p.x-29}" y="${p.y-12}" width="58" height="24" rx="11" fill="#0c3137" opacity=".95"/><text x="${p.x}" y="${p.y+4}" text-anchor="middle" font-size="12" font-weight="bold" fill="#fff">${fmt(state.found)}</text></g>`;}
 }
 // Highlight selected best route, with proper legend.
 const selected=world.regions.find(r=>r.id===selectedRegion);
 if(selected&&world.mastUp){const options=world.routeOptions(selected.id).filter(o=>o.route).sort((a,b)=>a.route.cost-b.route.cost);
  if(options.length)body+=`<path d="${path(options[0].route.points)}" fill="none" stroke="#162c36" stroke-width="8" opacity=".8"/><path d="${path(options[0].route.points)}" fill="none" stroke="#fbd47b" stroke-width="4" stroke-dasharray="9 5"/>`;}
 if(showStarts)for(const site of scenario.launchSites){const p=xy(site.pos);body+=`<g><circle cx="${p.x}" cy="${p.y}" r="17" fill="#12383b" stroke="#f4d08b" stroke-width="2.2"/><path d="M${p.x} ${p.y-9} l8 15 h-16 Z" fill="#f2cd78"/><text x="${p.x+20}" y="${p.y+4}" font-size="11" font-weight="800" fill="#f4dfb4">${esc(site.name)}</text></g>`;}
 for(const t of world.teams){if(t.vehicle!=='drone'&&!showResponders&&selectedTeam!==t.id)continue;
  const a=world.getAgent(t.id),state=cmd.lastSeen.get(t.id),pos=offline?state?.pos||t.start:a.pos,p=xy(pos),sus=offline||a.down||world.tick-(state?.tick||0)>13;
  body+=`<g data-team="${esc(t.id)}" style="cursor:pointer"><circle cx="${p.x}" cy="${p.y}" r="${t.vehicle==='drone'?12:9}" fill="${sus?'#3f5158':'#153641'}" stroke="${sus?'#adb4b7':t.color}" stroke-width="3" ${sus?'stroke-dasharray="4 3"':''}/><text x="${p.x}" y="${p.y+4.2}" text-anchor="middle" font-size="12" fill="#fff" pointer-events="none">${offline?'?':a.down?'×':t.vehicle==='drone'?'◆':t.vehicle==='boat'?'▰':'●'}</text><title>${esc(t.name)}${offline?' · last known location':''}</title></g>`;
 }
 if(offline){body+=`<rect width="${W}" height="${H}" fill="#101d24" opacity=".22" pointer-events="none"/><rect x="12" y="${H-64}" width="425" height="48" rx="7" fill="#172730" opacity=".96"/><text x="23" y="${H-35}" fill="#fff" font-size="14" font-weight="bold">⚠ HQ POSITIONS FROZEN — LAST RECEIVED ONLY</text>`;}
 $('mapLive').innerHTML=body;
 $('mapGeometry').textContent=`RECTANGULAR AREA · ${scenario.sectors.length} nearest-assigned drone sectors · ${world.regions.length} search zones`; 
}
function droneRadar(){const a=world.getAgent(selectedTeam);if(!a||a.vehicle!=='drone')return;
 const radar=$('droneMap'),local=pos=>({x:475+(pos.lng-a.pos.lng)*111195*Math.cos(a.pos.lat*Math.PI/180)*.18,y:285-(pos.lat-a.pos.lat)*111195*.18});
 const localPath=pts=>pts.map((p,i)=>{const q=local(p);return`${i?'L':'M'}${q.x.toFixed(1)} ${q.y.toFixed(1)}`;}).join(' ');
 let html='<rect width="950" height="570" fill="#15383b"/>';
 for(let i=0;i<=950;i+=38)html+=`<line x1="${i}" y1="0" x2="${i}" y2="570" stroke="#2e5758" opacity=".44"/>`;
 for(let i=0;i<=570;i+=38)html+=`<line x1="0" y1="${i}" x2="950" y2="${i}" stroke="#2e5758" opacity=".44"/>`;
 for(const s of scenario.sectors){const corners=boxPoints(s).map(local);const d=corners.map((p,i)=>`${i?'L':'M'}${p.x} ${p.y}`).join(' ')+'Z';html+=`<path d="${d}" fill="${s.id===a.sector?'#2c7363':'#284654'}" fill-opacity=".24" stroke="${s.id===a.sector?'#a0e3bd':'#59818d'}" stroke-width="2" stroke-dasharray="9 7"/>`;}
 for(const r of a.visibleRegions.values()){const p=local(r.pos);if(p.x< -50||p.x>1000||p.y< -50||p.y>620)continue;const found=a.knownFound.get(r.id)||0;html+=`<circle cx="${p.x}" cy="${p.y}" r="${Math.max(9,Math.min(28,Math.sqrt(r.expected)*.8))}" fill="${found?'#48d1a2':'#f0b167'}" opacity=".38"/><text x="${p.x}" y="${p.y+4}" font-size="12" font-weight="bold" fill="#fff" text-anchor="middle">${found}</text>`;}
 // Modelled sighting coordinates from this drone's own local scan, not from command or other drones.
 const geoReports=a.history.filter(e=>e.origin===a.id&&e.type==='SURVEY'&&e.sightings?.length).slice(-9);
 for(const report of geoReports.slice(-4))for(const loc of report.sightings){const p=local(loc);
  html+=`<circle cx="${p.x}" cy="${p.y}" r="6" fill="#ffde86" stroke="#602d22" stroke-width="2"><title>${loc.count} modelled located at ${loc.lat.toFixed(6)}, ${loc.lng.toFixed(6)}</title></circle>`;}
 const trail=a.flightTrail||[];
 if(trail.length>1)html+=`<path d="${localPath(trail)}" stroke="#f7df92" stroke-width="4" stroke-linejoin="round" fill="none"/>`;
 html+=`<circle cx="475" cy="285" r="74" fill="#7ceccb" opacity=".075" stroke="#7ceccb" stroke-dasharray="6 7"/><path d="M475 258 L494 314 L475 307 L456 314 Z" stroke="#defdf1" stroke-width="3" fill="#3cbeb1"/><text x="494" y="267" font-size="14" fill="#fff">${esc(a.id)}</text>`;
 if(a.target){const dest=a.visibleRegions.get(a.target);if(dest){const p=local(dest.pos);html+=`<line x1="475" y1="285" x2="${p.x}" y2="${p.y}" stroke="#f7d481" stroke-width="2" stroke-dasharray="9 6"/>`;}}
 radar.innerHTML=html;
 $('sensorStamp').textContent=`${a.id.toUpperCase()} · T+${world.tick} · ${world.mastUp?'HQ LINK ONLINE':'OFFLINE · ONBOARD SENSOR LIVE'}`;
}
function renderDrone(){const ds=$('droneSelect'),drones=world.teams.filter(t=>t.vehicle==='drone');
 if(!drones.length){$('droneTelemetry').innerHTML='<p class="muted">Configure at least one drone.</p>';return;}
 if(!world.getAgent(selectedTeam)||world.getAgent(selectedTeam).vehicle!=='drone')selectedTeam=drones[0].id;
 const a=world.getAgent(selectedTeam);ds.innerHTML=drones.map(t=>`<option value="${t.id}">${esc(t.name)} · ${t.sector}</option>`).join('');ds.value=selectedTeam;
 const peers=world.agents.filter(b=>b.id!==a.id&&!b.down&&metres(a.pos,b.pos)<230).map(b=>b.id);
 const radio=!a.down&&peers.length>0,link=world.mastUp&&!a.down;
 $('droneTelemetry').innerHTML=`<div class="telemetryGrid"><div><span>SPEED</span><strong>${(a.speedMPerTick*.06).toFixed(1)} km/h</strong></div><div><span>DISTANCE FLOWN</span><strong>${(a.distanceM/1000).toFixed(2)} km</strong></div><div><span>HQ LINK</span><strong class="${link?'good':'bad'}">${link?'ONLINE':'OFFLINE'}</strong></div><div><span>PEER RADIO</span><strong class="${radio?'good':'warn'}">${radio?`${peers.length} in range`:'NONE'}</strong></div><div><span>ASSIGNED SECTOR</span><strong>${a.sector||'—'}</strong></div><div><span>START POINT</span><strong>${esc(scenario.launchSites.find(x=>x.id===a.launchSite)?.name||'Custom')}</strong></div><div><span>BATTERY</span><strong class="${a.battery<30?'bad':'good'}">${Math.round(a.battery)}%</strong></div><div><span>FLIGHT STATE</span><strong>${esc(a.flightState)}</strong></div><div class="coordTile"><span>CURRENT DRONE LOCATION · WGS84</span><strong>${Math.abs(a.pos.lat).toFixed(6)}° ${a.pos.lat<0?'S':'N'}<br>${Math.abs(a.pos.lng).toFixed(6)}° ${a.pos.lng<0?'W':'E'}</strong><small>${!world.mastUp?'Local GPS simulation continues; HQ cannot see this position.':'Synthetic GPS position.'}</small></div></div>`;
 const localFound=[...a.knownFound.values()].reduce((s,n)=>s+n,0),knownCoverage=[...a.progress.values()].reduce((s,n)=>s+n,0);
 $('droneDecisions').innerHTML=`<p><b>Current task:</b> ${esc(a.target||'Selecting next patrol zone')}</p><p><b>Mode:</b> ${a.down?'Drone unresponsive':a.flightState==='charging'?'Charging at external staging':a.flightState==='returning'?'Returning to staging to charge':a.waitingRescue?'Holding position until an emergency responder arrives':a.takeover?'Covering an overdue drone sector':a.flightState==='awaiting-free-pad'?'Waiting for an unoccupied charging site':a.flightState==='patrolling'?'Continuing patrol for unregistered or missed people':'Searching assigned sector'}</p><p><b>People located in local memory:</b> ${fmt(localFound)}</p><p><b>Regional scan work:</b> ${knownCoverage.toFixed(1)} zone-equivalents</p><p><b>Learning policy:</b> ${a.q.map(n=>n.toFixed(1)).join(' · ')}</p><p><b>Last peer sync:</b> ${a.lastPeerTick<0?'No short-range exchange':`T+${a.lastPeerTick}`}</p><p><b>Extra search passes:</b> ${Math.max(0,Math.round([...a.progress.values()].reduce((sum,n)=>sum+Math.max(0,n-1),0)*10)/10)} zone-equivalents beyond the initial sweep</p><small>These values remain available on the device during a mast outage, but are not visible to command until synchronization.</small>`;
 const sensorRand=rng(scenario.seed+world.tick*7391+Number(a.id.replace(/\D/g,''))*301);
 const sensorSample=[`THERMAL CANDIDATES: ${Math.floor(sensorRand()*9)} · not verified`,`WIND MODEL: ${(6+sensorRand()*17).toFixed(1)} km/h`,`VISUAL CLARITY: ${['CLEAR','LIGHT HAZE','PARTIAL OCCLUSION'][Math.floor(sensorRand()*3)]}`,`OBSTACLE PROXIMITY: ${[35,55,90,140][Math.floor(sensorRand()*4)]} m`];
 const latest=a.history.filter(e=>e.type==='SURVEY'||e.type==='POWER'||e.type==='HANDOVER').slice(-3).reverse().map(e=>`T+${e.tick} ${e.type==='SURVEY'?`Survey ${esc(e.region)}: +${e.found} located`:e.type==='POWER'?`Power: ${esc(e.state)}`:'Responder arrival confirmed'}`);
 $('sensorLog').innerHTML=`<div class="section-top"><span>SYNTHETIC SENSOR OUTPUT</span><span class="tag">MODELLED</span></div>${sensorSample.map(x=>`<div class="sensorEntry">${esc(x)}</div>`).join('')}${latest.map(x=>`<div class="sensorEntry event">${x}</div>`).join('')}`;
 const ownSightings=a.history.filter(e=>e.origin===a.id&&e.type==='SURVEY'&&e.sightings?.length).slice(-8).reverse();
 $('droneSightings').innerHTML=`<div class="section-top"><span>LOCATED PEOPLE · ONBOARD COORDINATES</span><span class="tag">LOCAL ONLY</span></div><small>Fictional geolocation clusters. Each coordinate refers to a modelled group of people, not verified individual GPS fixes.</small>${ownSightings.length?ownSightings.flatMap(ev=>ev.sightings.map(pt=>`<div class="sightingRow"><span><b>${esc(ev.region)}</b> · T+${ev.tick}<small>${pt.lat.toFixed(6)}, ${pt.lng.toFixed(6)}</small></span><strong>+${fmt(pt.count)}</strong></div>`)).slice(0,12).join(''):'<p class="muted">No confirmed local sightings yet. Surveying continues even after the estimated population is located.</p>'}`;

 $('droneControl').innerHTML=`<p class="muted">${a.down?'This drone is marked unavailable. Other agents can take over after its heartbeat becomes stale.':'Its current flight trajectory is autonomous; emergency response still requires human approval.'}</p><div class="review-buttons"><button id="droneGround" class="${a.down?'primary':'danger'}">${a.down?'Restore drone':'Simulate drone loss'}</button><button id="droneRelocate" class="outline">Change launch</button></div>`;
 $('droneGround').onclick=()=>{world.ground(a.id);baseline.ground(a.id);render();};
 $('droneRelocate').onclick=()=>{interaction='start';tab='command';render();toast('Click the command map to move this drone launch point.');};
 droneRadar();}
function render(){const offline=!world.mastUp,command=world.commandView(),summary=world.simSummary();
 $('clock').textContent=`T+${String(world.tick).padStart(3,'0')} MIN`;
 $('locationName').textContent=`${(PRESETS[config.area]||PRESETS.custom).name} · ${scenario.bounds.areaKm2.toFixed(1)} km² rectangular perimeter`;
 $('network').textContent=offline?'● NETWORK DOWN':'● MAST ONLINE';$('network').classList.toggle('offline',offline);
 $('outageBanner').hidden=!offline&&!(world.resyncAt>=0&&world.tick-world.resyncAt<9);
 $('outageBanner').className=`outageBanner ${offline?'isDown':'restored'}`;
 $('outageBanner').innerHTML=offline?`<b>⚠ COMMUNICATION FAILURE — HQ DATA FROZEN</b><span>Command cannot see live drone positions or new discoveries. Field agents continue local search and short-range peer radio.</span>`:`<b>✓ CONNECTION RESTORED — ${fmt(world.resyncDelta)} DISCOVERIES RECONCILED</b><span>Latest local survey logs and position heartbeats have reached command.</span>`;
 $('mast').textContent=offline?'✓ Restore mast':'✕ Mast failure';$('play').textContent=playing?'Ⅱ Pause':'▶ Start';$('water').value=world.floodLevel;
 $('waterText').textContent=['Normal','Rising','Severe','Critical'][world.floodLevel];
 $('stats').innerHTML=`<div class="stat"><span>PEOPLE EXPECTED</span><strong>${fmt(summary.expected)}</strong><small>All allocated to search regions</small></div><div class="stat ${offline?'stale':''}"><span>PEOPLE FOUND · HQ CONFIRMED</span><strong>${fmt(command.reported)}</strong><small>${offline?'Last synced · may be outdated':'Synced field reports'}</small></div><div class="stat"><span>STILL UNACCOUNTED FOR · HQ</span><strong>${fmt(Math.max(0,summary.expected-command.reported))}</strong><small>${offline?'Estimate based on last sync':'Not yet reported located'}</small></div><div class="stat"><span>DRONES REQUIRING ATTENTION</span><strong>${world.agents.filter(a=>a.vehicle==='drone'&&((world.mastUp&&a.down)||(world.tick-(command.lastSeen.get(a.id)?.tick||0)>13))).length}</strong><small>Missing or overdue at command</small></div>`;
 $('tabCommand').classList.toggle('active',tab==='command');$('tabDrone').classList.toggle('active',tab==='drone');
 $('commandView').hidden=tab!=='command';$('droneView').hidden=tab!=='drone';
 $('mapSource').textContent=`${view==='street'?'OpenStreetMap basemap':view==='topo'?'Topographic basemap':'Offline terrain'} · ${world.graph.real?'imported OSM roads':'synthetic road routes'}`;
 $('mapHint').textContent=interaction==='drawBounds'?'DRAG a search rectangle; release to apply':interaction==='placeLaunch'?`Click OUTSIDE the rectangle to place ${requestedLaunchSite}`:interaction==='add'?'Click the map to create a new search region':interaction==='start'?'Click the new launch location':'Drag to pan · click regions to inspect';
 $('preflight').hidden=world.tick>0; $('drawMission').classList.toggle('planning',interaction==='drawBounds');$('planLaunch').classList.toggle('planning',interaction==='placeLaunch');
 document.querySelectorAll('[data-view]').forEach(b=>b.classList.toggle('active',b.dataset.view===view));
 $('riskBtn').classList.toggle('active',overlay);$('launchBtn').classList.toggle('active',showStarts);$('allTeamsBtn').classList.toggle('active',showResponders);
 if(tab==='command'){drawMap();renderSidebar(command);}else renderDrone();
 $('feed').innerHTML=world.audit.filter(x=>world.mastUp||x.tick<=world.mastLostAt||/NETWORK FAILURE|Mast down|Communication restored|Mast restored|Commander|Road/.test(x.text)).slice(0,4).map(x=>`<div class="logitem"><b>+${x.tick}m</b><span>${esc(x.text)}</span></div>`).join('')||'<p class="muted">Field updates appear here after deployment.</p>';
}
function renderSidebar(command){let target=world.regions.find(x=>x.id===selectedRegion);
 if(!target)target=[...world.regions].sort((a,b)=>threat(b)-threat(a))[0];if(target&&!selectedRegion)selectedRegion=target.id;
 const lostAt=world.mastLostAt,visibleRecs=world.recommendations.filter(r=>r.status==='pending'&&(world.mastUp||r.tick<=lostAt));
 const rec=visibleRecs.find(x=>x.region===selectedRegion)||visibleRecs[0],region=rec?world.regions.find(x=>x.id===rec.region):target;
 const state=region?displayFor(region,command):null,nearest=region&&world.mastUp?world.nearestResponder(region.id):null;
 $('actionCard').innerHTML=!region?'<p>No regions configured.</p>':`<div class="review-top"><span class="riskbadge ${threat(region)>.7?'':'elevated'}">${threat(region)>.7?'HIGH':'MODERATE'} THREAT</span><span class="region-id">${esc(region.id)}</span></div><h2>${esc(region.name)}</h2><p>${fmt(region.expected)} expected · ${fmt(state.found)} HQ located · ${Math.round(state.coverage*100)}% reported surveyed</p><div class="action-info"><span>Nearest available unit</span><b>${nearest?`${esc(nearest.agent.id)} · ${Math.ceil(nearest.route.cost)} min`:world.mastUp?'No reachable free unit':'Awaiting command link'}</b></div><div class="access-list"><span>${region.sector||'Unassigned'} drone sector</span><span>${!world.mastUp?'Field status unverified':region.responderArrived?'Responder on site':'Awaiting rescue arrival'}</span></div><div class="review-buttons">${rec?`<button class="primary" data-review="approved" data-rec="${esc(rec.id)}">✓ Dispatch nearest</button><button class="outline" data-review="held" data-rec="${esc(rec.id)}">Hold / review</button>`:'<button class="outline" id="showZone">Select on map</button>'}</div><small class="review-caption">${rec?`Field report from ${esc(rec.reportedBy)}. Only ONE eligible nearest responder is assigned; other teams keep searching.`:'Human approval required for rescue assignments. No fleet-wide redirect.'}</small>`;
 $('taskCount').textContent=`${world.regions.filter(x=>(command.coverageByRegion.get(x.id)||0)<.99).length} OPEN`;
 $('regionsList').innerHTML=[...world.regions].sort((a,b)=>(selectedRegion===b.id)-(selectedRegion===a.id)||threat(b)-threat(a)).slice(0,9).map(r=>{const state=displayFor(r,command);return`<button class="region-row ${r.id===selectedRegion?'selected':''}" data-select-region="${esc(r.id)}"><i class="region-dot" style="background:${state.color}"></i><span class="region-name"><b>${esc(r.name)}</b><small>${fmt(r.expected)} expected · ${r.sector||'operator added'} · ${Math.round(state.coverage*100)}%</small></span><b class="region-count">${fmt(state.found)}</b></button>`;}).join('');
 const list=world.teams.filter(t=>t.vehicle==='drone'||showResponders);
 const chargeWarnings=world.teams.filter(t=>t.vehicle==='drone').map(t=>({t,known:command.lastSeen.get(t.id)})).filter(({known})=>known&&(known.battery<=28||['returning','charging','awaiting-free-pad'].includes(known.flightState)));
 $('batteryAlerts').innerHTML=chargeWarnings.map(({t,known})=>{const site=scenario.launchSites.find(s=>s.id===known.rechargeSite);const offline=!world.mastUp;
  return `<div class="batteryAlert ${offline?'staleCharge':''}">⚡ <b>${esc(t.name)} · ${Math.round(known.battery)}%</b><small>${offline?'Last received before mast failure':known.flightState==='charging'?'Charging at staging':known.flightState==='awaiting-free-pad'?'No unoccupied charging site':site?`Nearest free charger reserved: ${esc(site.name)}`:'Battery nearing 20% — charging required'}${offline?' · unverified':''}</small></div>`;
 }).join('');
 $('responderList').innerHTML=list.slice(0,showResponders?80:18).map(t=>{const a=world.getAgent(t.id),known=command.lastSeen.get(t.id),stale=(!world.mastUp)||world.tick-(known?.tick||0)>13,down=world.mastUp&&a.down;
  return`<button class="team-row" data-select-team="${esc(t.id)}"><span class="team-mark" style="border-color:${t.color}">${t.vehicle==='drone'?'◆':t.vehicle==='boat'?'▰':'●'}</span><span><b>${esc(t.name)}</b><small>${esc(t.sector||a.dispatchJob||'Field responder')} · ${world.mastUp?esc(a.target||'Available'):'HQ location unavailable'}</small></span><strong class="${down||stale?'bad':'good'}">${down?'DOWN':stale?'STALE':'ACTIVE'}</strong></button>`;}).join('')||'<p>No teams deployed.</p>';
}
function dialog(html){$('dialogBody').innerHTML=`<button id="closeDialog" class="modal-x">×</button>${html}`;$('dialog').showModal();$('closeDialog').onclick=closeDialog;}
function closeDialog(){if($('dialog').open)$('dialog').close();}
function toast(msg){const e=$('toast');e.textContent=msg;e.classList.add('visible');clearTimeout(toast.timer);toast.timer=setTimeout(()=>e.classList.remove('visible'),3300);}
const presets=Object.entries(PRESETS).filter(([id])=>id!=='custom').map(([id,v])=>`<option value="${id}">${v.name}</option>`).join('');
function configure(){dialog(`<div class="overline">MISSION CONFIGURATION</div><h2>Deploy the response network</h2><p class="muted">The rectangular search perimeter grows with the number of drones (area proportional to drone count). Drone sectors are always equal in area. Pins represent proposed coordinates, not verified landing zones. Use the map to choose real external launch sites.</p><form id="settings"><div class="form-grid"><label>Fictional residents (1–50,000)<input type="number" id="settingPeople" min="1" max="50000" value="${config.people}" required></label><label>Autonomous drones (0–20)<input type="number" id="settingDrones" min="0" max="20" value="${config.drones}" required></label><label>Ground / boat / foot teams (0–30)<input id="settingResponders" type="number" min="0" max="30" value="${config.responders}" required></label><label>Geographic area<select id="settingArea">${presets}<option value="custom">Custom coordinates</option></select></label><label>Latitude<input id="settingLat" type="number" step=".00001" value="${config.lat??(PRESETS[config.area]||PRESETS.custom).lat}"></label><label>Longitude<input id="settingLng" type="number" step=".00001" value="${config.lng??(PRESETS[config.area]||PRESETS.custom).lng}"></label><label>Base mission span at 4 drones (1–12)<input id="settingSpan" type="number" min="1" max="12" step=".5" value="${config.span}"></label><label>Drone launch base<select id="settingLaunch"><option value="distributed">Across all staging sites</option><option value="command">Proposed staging A</option><option value="school">Proposed staging B</option><option value="hospital">Proposed staging C</option><option value="field">Proposed staging D</option></select></label><label>Random seed<input id="settingSeed" type="number" min="1" max="99999999" value="${config.seed}"></label></div><div class="modal-actions"><button type="button" class="outline" id="randomSeed">Randomize scenario</button><button type="submit" class="primary">Generate new mission</button></div></form><hr><h3>Road context (optional)</h3><p class="muted">You may import OpenStreetMap Overpass JSON. Without it, routing uses a clearly labelled synthetic road graph.</p><label class="outline filelabel">Import OSM JSON<input type="file" id="osmFile" accept=".json,application/json"></label><small id="osmStatus"></small>`);
 $('settingArea').value=config.area;$('settingLaunch').value=config.launchMode;
 $('settingArea').onchange=ev=>{const p=PRESETS[ev.target.value];if(p&&ev.target.value!=='custom'){$('settingLat').value=p.lat;$('settingLng').value=p.lng;$('settingSpan').value=p.span;}};
 $('randomSeed').onclick=()=>$('settingSeed').value=Math.floor(Date.now()%99999999)+1;
 $('settings').onsubmit=ev=>{ev.preventDefault();config={people:clamp(+$('settingPeople').value,1,50000),drones:clamp(+$('settingDrones').value,0,20),responders:clamp(+$('settingResponders').value,0,30),area:$('settingArea').value,lat:+$('settingLat').value,lng:+$('settingLng').value,span:clamp(+$('settingSpan').value,1,12),launchMode:$('settingLaunch').value,seed:clamp(+$('settingSeed').value,1,99999999),rectangle:null,launchSites:[]};roadData=null;closeDialog();initialize();render();toast('New mission generated with equal-area drone sectors.');};
 $('osmFile').onchange=async ev=>{try{roadData=importOverpass(JSON.parse(await ev.target.files[0].text()));closeDialog();initialize();render();toast('Imported real OSM road geometry.');}catch(error){$('osmStatus').textContent=error.message;}};
}
function addZone(pos){dialog(`<div class="overline">NEW SEARCH TASK</div><h2>Add an area while operating</h2><p class="muted">This does not interrupt the simulation. Offline drones learn about the new zone only when a message reaches them.</p><form id="zoneForm"><label>Search area name<input id="zoneName" value="Priority location" maxlength="70" required></label><div class="form-grid"><label>Additional people expected<input id="zonePeople" type="number" min="0" max="${50000-world.expected()}" value="0"></label><label>Threat priority<select id="zonePriority"><option value="3">High</option><option value="2">Elevated</option><option value="1">Standard</option></select></label></div><button type="submit" class="primary">Add search task</button></form>`);
 $('zoneForm').onsubmit=ev=>{ev.preventDefault();const input={...pos,name:$('zoneName').value,expected:+$('zonePeople').value,priority:+$('zonePriority').value};const r=world.addSearchRegion(input);baseline.addSearchRegion(input);selectedRegion=r.id;interaction='inspect';closeDialog();render();toast('Zone added. Awaiting network exchange for offline drones.');};}
function teamDialog(id){const a=world.getAgent(id),t=world.team(id);if(!a)return;selectedTeam=id;
 dialog(`<div class="overline">RESPONDER DETAIL</div><h2>${esc(t.name)}</h2><p class="muted">Assigned sector: ${esc(t.sector||'Ground operations')}. ${a.down?'This actor is offline / grounded.':'Operates independently using its own local observations and received peer reports.'}</p><div class="inspect-grid"><span>Distance travelled<b>${(a.distanceM/1000).toFixed(2)} km</b></span><span>Local events<b>${a.log.size}</b></span><span>Current zone<b>${a.target||a.dispatchJob||'—'}</b></span></div><div class="modal-actions"><button id="teamGround" class="${a.down?'primary':'danger'}">${a.down?'Restore':'Simulate loss'}</button><button id="teamLaunch" class="outline">Relocate start</button>${a.vehicle==='drone'?'<button id="openPOV" class="primary">Open drone POV</button>':''}</div>`);
 $('teamGround').onclick=()=>{world.ground(id);baseline.ground(id);closeDialog();render();};
 $('teamLaunch').onclick=()=>{interaction='start';closeDialog();toast('Click a new starting location on the map.');};
 if(a.vehicle==='drone')$('openPOV').onclick=()=>{tab='drone';closeDialog();render();};}
function proposeLaunch(){
 if(world.tick>0){toast('Pause and reset the mission to edit pre-flight staging locations.');return;}
 if(!scenario.drones)return toast('Configure at least one drone before placing launch sites.');
 dialog(`<div class="overline">PRE-FLIGHT MAP SETUP</div><h2>Place an external drone launch site</h2><p class="muted">Select a staging pin and then click a suitable position OUTSIDE the search rectangle on the street map. A pin is an exact map coordinate, not a claim that a roof/field is approved or safe for flight. Verify local airspace and landing permission.</p><label>Which external staging site?<select id="pickLaunch">${scenario.launchSites.map(x=>`<option value="${x.id}">${esc(x.name)} (${x.pos.lat.toFixed(5)}, ${x.pos.lng.toFixed(5)})</option>`).join('')}</select></label><div class="modal-actions"><button id="chooseLaunch" class="primary">Choose on map</button>${scenario.launchSites.length<scenario.drones?'<button id="addLaunchSite" class="outline" type="button">+ Add launch site</button>':''}</div><small>${scenario.launchSites.length} / ${scenario.drones} allowed staging sites. Each charging site holds one drone at a time.</small>`);
 $('pickLaunch').value=requestedLaunchSite;
 $('chooseLaunch').onclick=()=>{requestedLaunchSite=$('pickLaunch').value;interaction='placeLaunch';closeDialog();render();toast('Click a map location OUTSIDE the rectangle. Map coordinates will be saved.');};
 if($('addLaunchSite'))$('addLaunchSite').onclick=()=>{if(scenario.launchSites.length>=scenario.drones)return toast('Launch sites cannot exceed the number of drones.');
  const id=`site-${scenario.launchSites.length+1}`,ang=(scenario.launchSites.length+.5)*Math.PI/2;
  const x=(ang%Math.PI>.1?scenario.bounds.minX-300:scenario.bounds.maxX+300),y=(scenario.launchSites.length%2?scenario.bounds.maxY+220:scenario.bounds.minY-220);
  const pos=metersToLL(scenario.center,x,y);
  config={...config,launchSites:[...(config.launchSites||[]),{id,name:`Proposed staging ${scenario.launchSites.length+1}`,pos}]};
  requestedLaunchSite=id;closeDialog();initialize();render();toast('Additional site added. Click “Choose launch point” to position it precisely outside the box.');};

}
function applyRectangle(from,to){
 if(world.tick>0)return toast('Set mission boundaries before starting. Reset first.');
 const south=Math.min(from.lat,to.lat),north=Math.max(from.lat,to.lat),west=Math.min(from.lng,to.lng),east=Math.max(from.lng,to.lng);
 const vertical=metres({lat:south,lng:west},{lat:north,lng:west}),horizontal=metres({lat:south,lng:west},{lat:south,lng:east});
 if(vertical<350||horizontal<350)return toast('Rectangle too small. Drag at least 350 m in both directions.');
 if(vertical>16000||horizontal>16000)return toast('Rectangle too large. Use a search box under 16 km per side.');
 config={...config,rectangle:{south,north,west,east},area:'custom',lat:(south+north)/2,lng:(west+east)/2,launchSites:[]};
 interaction='inspect';drawStart=null;initialize();render();toast('Search rectangle saved. Next place external launch sites on the map.');
}
function applyLaunchLocation(p){
 if(world.tick>0)return toast('Launch positions must be chosen before the mission begins.');
 if(!outsideBounds(p,scenario.center,scenario.bounds,30))return toast('Choose a site at least 30 metres OUTSIDE the search rectangle.');
 const prior=config.launchSites||[],item={id:requestedLaunchSite,name:`Staging ${requestedLaunchSite.toUpperCase()} · map pin`,pos:p};
 config={...config,launchSites:[...prior.filter(x=>x.id!==requestedLaunchSite),item]};
 interaction='inspect';initialize();render();toast(`Staging point saved at ${p.lat.toFixed(5)}, ${p.lng.toFixed(5)}. Verify its suitability before real flight.`);
}
function showOfflineSplash(show){const node=$('offlineSplash');if(node)node.hidden=!show;}
function recoveryPayloadDownload(){
 const payload=world.recoveryPayload();if(!payload)return toast('No completed outage recovery is available.');
 const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});
 const url=URL.createObjectURL(blob),link=document.createElement('a');
 link.href=url;link.download=`respond-n8n-${payload.batchId}.json`;link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
}
function renderRecovery(){
 const node=$('recoverySplash');if(!node||!recoveryView){if(node)node.hidden=true;return;}
 const b=recoveryView.payload.recovery;node.hidden=false;
 $('recoverySummary').innerHTML=`<b>${fmt(b.reportsReconciled)} offline reports</b> reconciled from ${fmt(b.teams.length)} field units, including <b>${fmt(b.newlyLocated)} newly reported people</b> across ${fmt(b.regions.length)} search areas.`;
 const states={demo:'SIMULATION ONLY — packet ready for n8n; nothing sent externally.',sending:'Forwarding recovered reports to n8n gateway…',accepted:'✓ n8n gateway accepted the batch. Downstream delivery depends on configured workflow recipients.',error:'⚠ n8n gateway could not acknowledge the batch. Export the packet or retry after checking the connection.'};
 $('recoveryDelivery').textContent=states[recoveryView.state]||states.demo;
 $('recoveryDelivery').dataset.state=recoveryView.state;
}
function hideRecovery(){if(recoveryDismissTimer)clearTimeout(recoveryDismissTimer);recoveryDismissTimer=null;recoveryView=null;renderRecovery();}
function scheduleRecoveryClose(){
 if(recoveryDismissTimer)clearTimeout(recoveryDismissTimer);
 // Keep the small splash long enough to present during the live demonstration.
 recoveryDismissTimer=setTimeout(hideRecovery,10500);
}
async function forwardRecovery(payload){
 if(!n8nEndpoint){recoveryView.state='demo';renderRecovery();scheduleRecoveryClose();return;}
 if(lastForwardedBatchId===payload.batchId){recoveryView.state='accepted';renderRecovery();scheduleRecoveryClose();return;}
 recoveryView.state='sending';renderRecovery();
 try{
  const response=await fetch(n8nEndpoint,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
  if(!response.ok)throw Error(`HTTP ${response.status}`);
  lastForwardedBatchId=payload.batchId;
  if(recoveryView?.payload.batchId===payload.batchId){recoveryView.state='accepted';renderRecovery();scheduleRecoveryClose();}
  world.timeline('Recovery batch accepted by configured n8n gateway; recipient delivery is not independently verified.');
 }catch(error){
  if(recoveryView?.payload.batchId===payload.batchId){recoveryView.state='error';renderRecovery();scheduleRecoveryClose();}
  world.timeline(`n8n gateway unavailable (${String(error.message).slice(0,80)}); reports retained for retry/export.`);
 }
}
function showRestored(){
 showOfflineSplash(false);const payload=world.recoveryPayload();if(!payload)return;
 recoveryView={payload,state:'demo'};renderRecovery();
 void forwardRecovery(payload);
}
function updateMast(up){
 const wasUp=world.mastUp;
 world.setMast(up);baseline.setMast(up);
 if(wasUp&&!up){hideRecovery();showOfflineSplash(true);}
 if(!wasUp&&up)showRestored();
 render();
}
function n8nConfig(){
 dialog(`<div class="overline">OUTSIDE-WORLD GATEWAY</div><h2>n8n recovery notifications</h2><p class="muted">On reconnection, RESPOND sends ONE fictional exercise batch to your configured webhook. Your n8n workflow can route it to authorised council, rescue-lead and news-demo contacts. A successful webhook response does not prove those notifications were delivered.</p><label>Webhook endpoint<input id="n8nUrl" type="text" value="${esc(n8nEndpoint)}" placeholder="/api/recovery or https://your-n8n.example/webhook/respond-recovery"></label><small>Leave blank for a local-only simulation. Use the included Node gateway to avoid browser CORS issues. Never use real emergency recipients in a demonstration without authorisation.</small><div class="modal-actions"><button id="n8nSave" class="primary">Save endpoint for this session</button><button id="n8nTest" class="outline">Retry last recovered batch</button></div>`);
 $('n8nSave').onclick=()=>{
  const value=$('n8nUrl').value.trim();
  if(value&&!/^\/api\/recovery$|^https:\/\/|^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?\//.test(value))return toast('Use an HTTPS URL, local HTTP webhook or /api/recovery.');
  n8nEndpoint=value;gatewayReady=!!value;closeDialog();toast(value?'n8n forwarding enabled for the next recovery.':'Demo mode: no outbound messages.');
 };
 $('n8nTest').onclick=()=>{const batch=world.recoveryPayload();if(!batch)return toast('Restore a mast outage first.');const value=$('n8nUrl').value.trim();if(value)n8nEndpoint=value;recoveryView={payload:batch,state:'demo'};closeDialog();void forwardRecovery(batch);};
}

function reset(){showOfflineSplash(false);hideRecovery();lastForwardedBatchId='';interaction='inspect';drawStart=null;initialize();render();}
function exportReport(){const blob=new Blob([JSON.stringify(world.situationReport(),null,2)],{type:'application/json'}),url=URL.createObjectURL(blob),link=document.createElement('a');link.href=url;link.download=`respond-${world.tick}.json`;link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}
function step(){world.step();baseline.step();render();}
function bind(){
 $('recoveryClose').onclick=hideRecovery;$('recoveryDownload').onclick=recoveryPayloadDownload;$('n8nBtn').onclick=n8nConfig;
 $('offlineToPOV').onclick=()=>{showOfflineSplash(false);tab='drone';render();};$('offlineToHQ').onclick=()=>{showOfflineSplash(false);tab='command';render();};
 $('tabCommand').onclick=()=>{tab='command';render();};$('tabDrone').onclick=()=>{tab='drone';render();};
 $('droneSelect').onchange=ev=>{selectedTeam=ev.target.value;render();};
 $('scenarioBtn').onclick=configure;
 $('drawMission').onclick=()=>{if(world.tick>0)return toast('Reset before redrawing the mission.');interaction='drawBounds';drawStart=null;render();toast('Drag from one corner to the opposite corner of the search rectangle.');};
 $('planLaunch').onclick=proposeLaunch;$('play').onclick=()=>{if(!playing&&world.tick===0&&!(config.rectangle))toast('Demo perimeter in use. You can draw a custom rectangle before launching.');playing=!playing;render();};$('step').onclick=()=>{playing=false;step();};
 $('mast').onclick=()=>updateMast(!world.mastUp);
 $('reset').onclick=reset;$('compare').onclick=()=>{const a=world.simSummary(),b=baseline.simSummary();dialog(`<div class="overline">COMMUNICATION LOSS EXPERIMENT</div><h2>Distributed vs hub-dependent response</h2><p class="muted">Each system begins with the same scenario. Hub-dependent agents finish an existing task but cannot receive a new one after the mast fails.</p><div class="inspect-grid"><span>Independent agents<b>${fmt(a.found)}</b></span><span>Centralised agents<b>${fmt(b.found)}</b></span><span>Difference<b>${fmt(a.found-b.found)}</b></span></div><small>This simulated comparison is not a field-validated prediction.</small>`);};
 $('speed').onchange=ev=>speed=+ev.target.value;$('water').oninput=ev=>{world.flood(+ev.target.value);baseline.flood(+ev.target.value);render();};$('export').onclick=exportReport;
 $('riskBtn').onclick=()=>{overlay=!overlay;render();};$('launchBtn').onclick=()=>{showStarts=!showStarts;render();};$('allTeamsBtn').onclick=()=>{showResponders=!showResponders;render();};$('teamExpand').onclick=()=>{showResponders=!showResponders;render();};
 $('addSearch').onclick=()=>{interaction='add';render();toast('Click the map to add a search zone.');};
 $('useView').onclick=()=>{config={...config,area:'custom',lat:mapCenter.lat,lng:mapCenter.lng};roadData=null;reset();};
 $('zoomIn').onclick=()=>{zoom=clamp(zoom+1,10,17);render();};$('zoomOut').onclick=()=>{zoom=clamp(zoom-1,10,17);render();};$('recenter').onclick=()=>{mapCenter={...scenario.center};zoom=fitMissionZoom();render();};
 document.querySelectorAll('[data-view]').forEach(b=>b.onclick=()=>{view=b.dataset.view;tilesKey='';render();});
 const svg=$('map');svg.onpointerdown=ev=>{if(ev.button!==0)return;didDrag=false;if(interaction==='drawBounds'){const rect=svg.getBoundingClientRect();drawStart={x:(ev.clientX-rect.left)/rect.width*W,y:(ev.clientY-rect.top)/rect.height*H};svg.setPointerCapture(ev.pointerId);return;}dragging={x:ev.clientX,y:ev.clientY,center:{...mapCenter}};svg.setPointerCapture(ev.pointerId);};
 svg.onpointermove=ev=>{const rect=svg.getBoundingClientRect();if(drawStart&&interaction==='drawBounds'){const x=(ev.clientX-rect.left)/rect.width*W,y=(ev.clientY-rect.top)/rect.height*H;const left=Math.min(drawStart.x,x),top=Math.min(drawStart.y,y),width=Math.abs(x-drawStart.x),height=Math.abs(y-drawStart.y);$('drawPreview').innerHTML=`<rect x="${left}" y="${top}" width="${width}" height="${height}" stroke="#fbd47b" fill="#8fecc0" fill-opacity=".16" stroke-width="3" stroke-dasharray="10 5"/>`;return;}if(!dragging)return;const dx=(ev.clientX-dragging.x)/rect.width*W,dy=(ev.clientY-dragging.y)/rect.height*H;if(Math.abs(dx)+Math.abs(dy)>7)didDrag=true;if(didDrag){const o=project(dragging.center);mapCenter=unproject(o.x-dx,o.y-dy);drawMap();}};
 svg.onpointerup=ev=>{if(interaction==='drawBounds'&&drawStart){const rect=svg.getBoundingClientRect(),x=clamp((ev.clientX-rect.left)/rect.width*W,0,W),y=clamp((ev.clientY-rect.top)/rect.height*H,0,H),start=ll(drawStart.x,drawStart.y),end=ll(x,y);drawStart=null;$('drawPreview').innerHTML='';didDrag=true;applyRectangle(start,end);return;}dragging=null;};
 $('mapouter').addEventListener('wheel',ev=>{ev.preventDefault();zoom=clamp(zoom+(ev.deltaY<0?1:-1),10,17);render();},{passive:false});
 $('mapouter').onclick=ev=>{if(didDrag){didDrag=false;return;}const rect=svg.getBoundingClientRect(),px=(ev.clientX-rect.left)/rect.width*W,py=(ev.clientY-rect.top)/rect.height*H;if(px<0||px>W||py<0||py>H)return;const position=ll(px,py);
  if(interaction==='drawBounds')return;
  if(interaction==='placeLaunch'){applyLaunchLocation(position);return;}
  if(interaction==='add'){addZone(position);return;}
  if(interaction==='start'){if(world.getAgent(selectedTeam)?.vehicle==='drone'&&!outsideBounds(position,scenario.center,scenario.bounds,30))return toast('Drone staging must be outside the search box.');world.moveStart(selectedTeam,position);baseline.moveStart(selectedTeam,position);interaction='inspect';render();return;}
  const reg=ev.target.closest?.('[data-region]'),team=ev.target.closest?.('[data-team]');if(team){teamDialog(team.dataset.team);return;}if(reg){selectedRegion=reg.dataset.region;render();}
 };
 document.addEventListener('click',ev=>{const region=ev.target.closest('[data-select-region]'),team=ev.target.closest('[data-select-team]'),review=ev.target.closest('[data-review]');
 if(region){selectedRegion=region.dataset.selectRegion;render();}if(team)teamDialog(team.dataset.selectTeam);
 if(review){const ok=world.approve(review.dataset.rec,review.dataset.review);if(ok){render();toast('Commander decision saved. Only one eligible responder can be assigned.');}}
 });
}
mount();let remainder=0;setInterval(()=>{if(!playing)return;remainder+=speed*.25;let remaining=18;while(remainder>=1&&remaining--){world.step();baseline.step();remainder--;}render();},250);
window.RESPOND={get world(){return world;},get baseline(){return baseline;},get scenario(){return scenario;},reset,step,setMast(up){updateMast(up);},setFlood(level){world.flood(level);baseline.flood(level);render();},ground(id){world.ground(id);baseline.ground(id);render();},addRegion(args){const r=world.addSearchRegion(args);baseline.addSearchRegion(args);render();return r;},configure(cfg){config={...config,...cfg};reset();},selectDrone(id){selectedTeam=id;tab='drone';render();},getTab(){return tab;},applyRectangle,applyLaunchLocation,selectLaunch(id){requestedLaunchSite=id;interaction='placeLaunch';render();},getConfig(){return config;},getInteraction(){return interaction;},getGateway(){return {configured:!!n8nEndpoint,url:n8nEndpoint};},configureGateway(url){n8nEndpoint=url||'';gatewayReady=!!url;},getRecoveryView(){return recoveryView;}};

// Optional same-origin gateway auto-detection (only when launched with gateway-server.mjs).
if(location.protocol==='http:'||location.protocol==='https:'){
 fetch('/api/status').then(r=>r.ok?r.json():null).then(data=>{
  if(data?.configured&&!n8nEndpoint){n8nEndpoint='/api/recovery';gatewayReady=true;}
 }).catch(()=>{});
}
