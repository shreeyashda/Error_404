// RESPOND Regional — dependency-free, reproducible multi-agent flood-response simulation.
// All residents and hazards are fictional. Regions are irregular geospatial clusters, not grid cells.
export const clamp=(v,lo,hi)=>Math.min(hi,Math.max(lo,v));
export const PRESETS={
 kathmandu:{name:'Kathmandu · Bagmati',lat:27.6876,lng:85.3060,span:3.5,river:true},
 carlisle:{name:'Carlisle · Eden',lat:54.8954,lng:-2.9356,span:3.4,river:true},
 manchester:{name:'Manchester · Irwell',lat:53.4851,lng:-2.2533,span:3.5,river:true},
 york:{name:'York · Ouse',lat:53.9598,lng:-1.0855,span:3.4,river:true},
 custom:{name:'Custom search area',lat:27.6876,lng:85.3060,span:3.5,river:true}
};
export function rng(seed){let s=seed>>>0;return()=>{s+=0x6D2B79F5;let t=s;t=Math.imul(t^t>>>15,t|1);t^=t+Math.imul(t^t>>>7,t|61);return((t^t>>>14)>>>0)/4294967296;};}
export const metres=(a,b)=>Math.hypot((a.lat-b.lat)*111195,(a.lng-b.lng)*111195*Math.cos((a.lat+b.lat)*Math.PI/360));
export const metersToLL=(point,east,north)=>({lat:point.lat+north/111195,lng:point.lng+east/(111195*Math.cos(point.lat*Math.PI/180))});
const interpolate=(a,b,t)=>({lat:a.lat+(b.lat-a.lat)*t,lng:a.lng+(b.lng-a.lng)*t});
function gaussian(r){return Math.sqrt(-2*Math.log(Math.max(1e-9,r())))*Math.cos(2*Math.PI*r());}
function weightedSample(r,weight){let s=0;for(const w of weight)s+=w;let x=r()*s;for(let i=0;i<weight.length;i++){x-=weight[i];if(x<=0)return i;}return weight.length-1;}
const idSort=(a,b)=>a.id.localeCompare(b.id);
function riverPath(center,span,random){const pts=[];const phi=random()*6.28,base=(random()-.5)*span*120;for(let i=0;i<35;i++){const t=(i/34-.5)*span*1360;const east=t*Math.cos(phi)+Math.sin(t/290+phi)*span*205+Math.sin(t/115)*55;const north=t*Math.sin(phi)+Math.sin(t/360)*span*260+base;pts.push(metersToLL(center,east,north));}return pts;}
function toLocal(p,c){return {x:(p.lng-c.lng)*111195*Math.cos(c.lat*Math.PI/180),y:(p.lat-c.lat)*111195};}
function lineDistance(p,a,b,c){const P=toLocal(p,c),A=toLocal(a,c),B=toLocal(b,c),vx=B.x-A.x,vy=B.y-A.y;const t=clamp(((P.x-A.x)*vx+(P.y-A.y)*vy)/(vx*vx+vy*vy||1),0,1);return Math.hypot(P.x-A.x-t*vx,P.y-A.y-t*vy);}
function distanceToRiver(p,river,center){let min=Infinity;for(let i=1;i<river.length;i++)min=Math.min(min,lineDistance(p,river[i-1],river[i],center));return min;}
function makeTerrain(center,span,r){const river=riverPath(center,span,r),hotspots=[];for(let i=0;i<6;i++){hotspots.push({...metersToLL(center,(r()-.5)*span*950,(r()-.5)*span*790),radius:150+r()*450,strength:.3+r()*.68});}return{river,hotspots};}
function rawRisk(p,terrain,center){const river=Math.max(0,1-distanceToRiver(p,terrain.river,center)/530);let hot=0;for(const h of terrain.hotspots){const d=metres(p,h);hot+=h.strength*Math.exp(-d*d/(2*h.radius*h.radius));}return clamp(.08+.56*river+.53*hot,0,1);}
function inBounds(p,center,span){const l=toLocal(p,center);return Math.abs(l.x)<span*570&&Math.abs(l.y)<span*485;}
export function searchBounds(center,span,rectangle=null){
 const w=span*570,h=span*485;
 const a=rectangle?toLocal({lat:rectangle.south,lng:rectangle.west},center):{x:-w,y:-h};
 const b=rectangle?toLocal({lat:rectangle.north,lng:rectangle.east},center):{x:w,y:h};
 const minX=Math.min(a.x,b.x),maxX=Math.max(a.x,b.x),minY=Math.min(a.y,b.y),maxY=Math.max(a.y,b.y);
 return {minX,maxX,minY,maxY,width:maxX-minX,height:maxY-minY,areaKm2:((maxX-minX)*(maxY-minY))/1e6};
}
export function createSectors(center,span,count,rectangle=null){
 if(!count)return [];
 const b=searchBounds(center,span,rectangle),rows=Math.max(1,Math.floor(Math.sqrt(count)));
 const base=Math.floor(count/rows),extra=count%rows,sectors=[];let top=b.maxY;
 for(let row=0;row<rows;row++){
  const cols=base+(row<extra?1:0),height=b.height*cols/count,bottom=top-height;
  for(let col=0;col<cols;col++){
   const left=b.minX+b.width*col/cols,right=b.minX+b.width*(col+1)/cols;
   sectors.push({id:`S${String(sectors.length+1).padStart(2,'0')}`,index:sectors.length,
    minX:left,maxX:right,minY:bottom,maxY:top,
    center:metersToLL(center,(left+right)/2,(bottom+top)/2),areaKm2:((right-left)*(top-bottom))/1e6});
  }
  top=bottom;
 }
 return sectors;
}
export function sectorOf(point,center,sectors){
 if(!sectors.length)return null;const {x,y}=toLocal(point,center);
 return sectors.find(s=>x>=s.minX-1e-6&&x<=s.maxX+1e-6&&y>=s.minY-1e-6&&y<=s.maxY+1e-6)?.id||null;
}
function randomInSector(s,center,r){return metersToLL(center,s.minX+(s.maxX-s.minX)*(.12+.76*r()),s.minY+(s.maxY-s.minY)*(.12+.76*r()));}
export function outsideBounds(point,center,bounds,margin=0){const p=toLocal(point,center);return p.x<bounds.minX-margin||p.x>bounds.maxX+margin||p.y<bounds.minY-margin||p.y>bounds.maxY+margin;}
function launchSitesFor(center,bounds,provided=[],droneCount=4){
 const reference=[
 {id:'command',name:'Proposed staging A · NW',x:bounds.minX-240,y:bounds.maxY+180},
 {id:'school',name:'Proposed staging B · NE',x:bounds.maxX+240,y:bounds.maxY+180},
 {id:'hospital',name:'Proposed staging C · SE',x:bounds.maxX+240,y:bounds.minY-180},
 {id:'field',name:'Proposed staging D · SW',x:bounds.minX-240,y:bounds.minY-180}
 ];
 const templates=reference.slice(0,Math.min(reference.length,droneCount));
 for(const x of provided){
  if(templates.length>=droneCount)break;
  if(!templates.some(t=>t.id===x.id)&&x.pos&&outsideBounds(x.pos,center,bounds,15)){
   templates.push({id:x.id,name:x.name||`Proposed staging ${templates.length+1}`,x:0,y:0});
  }
 }
 return templates.map(x=>{const custom=provided.find(s=>s.id===x.id);
  const pos=custom?.pos&&outsideBounds(custom.pos,center,bounds,15)?custom.pos:metersToLL(center,x.x,x.y);
  return {id:x.id,name:custom?.name||x.name,pos:{...pos},verified:false};});
}
function organicRegions(center,span,terrain,r,amount,bounds){const regions=[];for(let i=0;i<amount;i++){let p,tries=0;do{p=metersToLL(center,bounds.minX+bounds.width*(.06+.88*r()),bounds.minY+bounds.height*(.06+.88*r()));tries++;}while(tries<70&&regions.some(reg=>metres(reg.pos,p)<Math.min(bounds.width,bounds.height)*.065));
 const raw=rawRisk(p,terrain,center);regions.push({id:`R${String(i+1).padStart(2,'0')}`,name:`Search zone ${String(i+1).padStart(2,'0')}`,pos:p,expected:0,found:0,surveyed:0,passes:0,atRisk:0,rawRisk:raw,priority:1+Math.floor(raw*2.8),radius:120+span*22+r()*95,shape:Math.floor(r()*10000),manual:false});}
 return regions;}
function allocateResidents(regions,count,r){const populations=new Array(regions.length).fill(0);const weights=regions.map(x=>Math.exp(1.22*gaussian(r))*Math.pow(1+.7*x.rawRisk,1.5));const denom=weights.reduce((a,b)=>a+b,0);let leftover=count;const remainders=[];for(let i=0;i<weights.length;i++){const f=count*weights[i]/denom;populations[i]=Math.floor(f);leftover-=populations[i];remainders.push({i,rem:f-populations[i]});}remainders.sort((a,b)=>b.rem-a.rem||a.i-b.i);for(let i=0;i<leftover;i++)populations[remainders[i].i]++;
 // Every synthetic individual has ONE explicit region index. Regional aggregates drive the live simulation.
 const personRegion=new Uint16Array(count);let k=0;for(let i=0;i<populations.length;i++){regions[i].expected=populations[i];regions[i].atRisk=Math.min(populations[i],Math.round(populations[i]*(.018+regions[i].rawRisk*.13)));for(let j=0;j<populations[i];j++)personRegion[k++]=i;}
 if(k!==count||populations.reduce((a,b)=>a+b,0)!==count)throw Error('Population partition invariant failed');
 return personRegion;}
function makeRoads(center,span,terrain,r,count=135){const nodes=[];for(let i=0;i<count;i++){const p=metersToLL(center,(r()-.5)*span*940,(r()-.5)*span*785);nodes.push({id:`N${i}`,pos:p});}
 const edges=[],known=new Set(),add=(a,b)=>{if(a===b)return;let k=[Math.min(a,b),Math.max(a,b)].join(':');if(known.has(k))return;known.add(k);const len=metres(nodes[a].pos,nodes[b].pos);const risk=rawRisk(interpolate(nodes[a].pos,nodes[b].pos,.5),terrain,center);edges.push({id:`E${edges.length}`,a,b,length:len,status:'open',risk,kind:'road',path:[nodes[a].pos,nodes[b].pos]});};
 // A sparse connected road network using a minimum-spanning tree plus short cross-connections.
 const active=[0],remain=new Set(nodes.map((_,i)=>i).slice(1));while(remain.size){let best={d:Infinity,a:0,b:0};for(const a of active)for(const b of remain){const d=metres(nodes[a].pos,nodes[b].pos);if(d<best.d)best={d,a,b};}add(best.a,best.b);active.push(best.b);remain.delete(best.b);}
 for(let i=0;i<nodes.length;i++){const near=nodes.map((n,j)=>({j,d:metres(nodes[i].pos,n.pos)})).filter(o=>o.j!==i).sort((a,b)=>a.d-b.d).slice(0,4);for(const nearNode of near)if(nearNode.d<span*235&&r()<.45)add(i,nearNode.j);}
 return {nodes,edges,source:'Procedurally generated streets · not surveyed road geometry',real:false};}
export function importOverpass(data){const elements=data?.elements||[],pts=new Map(elements.filter(e=>e.type==='node'&&Number.isFinite(e.lat)).map(e=>[e.id,{lat:e.lat,lng:e.lon}]));const ways=elements.filter(e=>e.type==='way'&&e.tags?.highway&&e.nodes?.length>1&&/^(primary|secondary|tertiary|residential|unclassified|living_street|service|footway|path|pedestrian)$/.test(e.tags.highway));if(!ways.length)throw Error('No street geometry found in OSM JSON');
 const nodeIds=new Map(),nodes=[],edges=[],edgeSeen=new Set();function point(id){if(!pts.has(id))return-1;if(!nodeIds.has(id)){nodeIds.set(id,nodes.length);nodes.push({id:`osm-${id}`,pos:pts.get(id)});}return nodeIds.get(id);}
 for(const w of ways){const step=Math.max(1,Math.ceil(w.nodes.length/18));for(let j=0;j<w.nodes.length-1;j+=step){const k=Math.min(j+step,w.nodes.length-1),a=point(w.nodes[j]),b=point(w.nodes[k]);if(a<0||b<0||a===b)continue;const path=w.nodes.slice(j,k+1).map(id=>pts.get(id)).filter(Boolean);if(path.length<2)continue;const key=`${Math.min(a,b)}:${Math.max(a,b)}`;if(edgeSeen.has(key))continue;edgeSeen.add(key);const length=path.slice(1).reduce((s,p,i)=>s+metres(path[i],p),0);edges.push({id:`osm-${w.id}-${j}`,a,b,length,status:'open',risk:0,kind:/footway|path|pedestrian/.test(w.tags.highway)?'footpath':'road',name:w.tags.name||'Road',path});}}
 if(nodes.length<25||edges.length<25)throw Error('Not enough road nodes in OSM selection');return{nodes,edges,source:`OpenStreetMap road geometry · imported (${nodes.length} nodes)`,real:true};}
function nearestNode(roads,p){let nearest=0,d=Infinity;roads.nodes.forEach((n,i)=>{const v=metres(n.pos,p);if(v<d){d=v;nearest=i;}});return nearest;}
function makeTeams(center,span,count,drones,roads,r,sectors,launchSites,launchMode,bounds){
 const teamTypes=['car','boat','foot'],teams=[];
 for(let i=0;i<count;i++){
  const vehicle=teamTypes[i%3],ang=i/count*2*Math.PI;
  const p=metersToLL(center,(Math.cos(ang)>0?bounds.maxX+260:bounds.minX-260),Math.sin(ang)*bounds.height*.49);
  teams.push({sector:null,launchSite:null,id:`responder-${i+1}`,name:`${vehicle==='boat'?'Rescue boat':vehicle==='foot'?'Foot team':'Road team'} ${i+1}`,vehicle,start:p,color:vehicle==='boat'?'#5da9ef':vehicle==='car'?'#efb96c':'#bc9cf5'});
 }
 const incoming=[];
 for(let i=0;i<drones;i++){
  const site=launchMode==='distributed'?launchSites[i%launchSites.length]:launchSites.find(x=>x.id===launchMode)||launchSites[0];
  incoming.push({sector:null,launchSite:site.id,id:`drone-${i+1}`,name:`Survey drone ${i+1}`,vehicle:'drone',start:{...site.pos},color:'#56d8bd'});
 }
 // One-to-one closest-first dispatch from external launch sites to equal-area search sectors.
 const remaining=new Set(sectors.map(s=>s.id)),pending=new Set(incoming.map(t=>t.id));
 while(pending.size){let best=null;for(const t of incoming.filter(t=>pending.has(t.id)))for(const sec of sectors.filter(s=>remaining.has(s.id))){const d=metres(t.start,sec.center);if(!best||d<best.d)best={t,sec,d};}best.t.sector=best.sec.id;pending.delete(best.t.id);remaining.delete(best.sec.id);}
 return teams.concat(incoming);
}
export function makeScenario({seed=2024,people=400,drones=3,responders=7,area='kathmandu',lat,lng,span,roadData=null,regionCount=null,launchMode='distributed',rectangle=null,launchSites:chosenLaunchSites=[]}={}){
 people=clamp(Math.floor(+people||400),1,50000);drones=clamp(Math.floor(+drones||0),0,20);responders=clamp(Math.floor(+responders||0),0,30);
 const preset=PRESETS[area]||PRESETS.custom;
 const validRectangle=rectangle&&Number.isFinite(rectangle.south)&&Number.isFinite(rectangle.north)&&Number.isFinite(rectangle.west)&&Number.isFinite(rectangle.east)&&rectangle.north>rectangle.south&&rectangle.east>rectangle.west;
 const center=validRectangle?{lat:(rectangle.south+rectangle.north)/2,lng:(rectangle.west+rectangle.east)/2}:{lat:Number.isFinite(+lat)&&lat!==undefined&&lat!==''?+lat:preset.lat,lng:Number.isFinite(+lng)&&lng!==undefined&&lng!==''?+lng:preset.lng};
 span=clamp((+span||preset.span)*Math.sqrt(Math.max(1,drones)/4),.65,12);
 const bounds=searchBounds(center,span,validRectangle?rectangle:null);
 const random=rng(seed),terrain=makeTerrain(center,span,random),n=regionCount??clamp(Math.round(14+Math.sqrt(people)*.13),18,55),regions=organicRegions(center,span,terrain,random,n,bounds);
 const sectors=createSectors(center,span,drones,validRectangle?rectangle:null),launchSites=launchSitesFor(center,bounds,chosenLaunchSites,drones);
 regions.forEach(reg=>reg.sector=sectorOf(reg.pos,center,sectors));
 const assignments=allocateResidents(regions,people,random);
 // Model a small number of unregistered residents, allocated to named regions, but not included in the prior estimate.
 const unregisteredCounts=regions.map((region,i)=>Math.max(0,Math.floor(region.expected*(random()*.035))+(i%11===0?1:0)));
 const unregisteredAssignments=new Uint16Array(unregisteredCounts.reduce((a,b)=>a+b,0));
 let extraIndex=0;unregisteredCounts.forEach((n,i)=>{regions[i].unexpected=n;for(let j=0;j<n;j++)unregisteredAssignments[extraIndex++]=i;});
 const roads=roadData||makeRoads(center,span,terrain,random),teams=makeTeams(center,span,responders,drones,roads,random,sectors,launchSites,launchMode,bounds);
 roads.edges.forEach(e=>{const p=e.path[Math.floor(e.path.length/2)];e.risk=rawRisk(p,terrain,center);});
 const fallbackWest=metersToLL(center,bounds.minX-260,0),fallbackEast=metersToLL(center,bounds.maxX+260,0);
 const shelters=[{name:'Incident staging · West',pos:launchSites[0]?.pos||fallbackWest},{name:'Incident staging · East',pos:launchSites[1]?.pos||fallbackEast}];
 regions.forEach(r=>r.present=r.expected);
 return{seed,center,span,people,drones,responders,area,terrain,regions,assignments,unregisteredAssignments,roads,teams,sectors,launchSites,launchMode,bounds,rectangle:validRectangle?rectangle:null,shelters,createdAt:0};
}
// Distances in metres per simulated minute. Drone cruise 30 km/h, hard cap 50 km/h.
export const MAX_DRONE_METRES_PER_TICK=50000/60;
const speeds={drone:500,car:88,boat:50,foot:28};
const possible=(type,status,kind,risk)=>type==='drone'||(status!=='blocked'&&(type==='boat'?status==='boat_only'||status==='open':type==='foot'?kind==='footpath'||status==='open':kind==='road'&&status==='open'));
function adjacency(roads){const adj=Array.from({length:roads.nodes.length},()=>[]);roads.edges.forEach((e,i)=>{adj[e.a].push(i);adj[e.b].push(i)});return adj;}
export function route(roads,adj,from,to,vehicle,statuses){if(vehicle==='drone')return{points:[from,to],distance:metres(from,to),cost:metres(from,to)/speeds.drone,vehicle};const source=nearestNode(roads,from),target=nearestNode(roads,to);const distance=new Float64Array(roads.nodes.length).fill(Infinity),prev=new Int32Array(roads.nodes.length).fill(-1),prevEdge=new Int32Array(roads.nodes.length).fill(-1),used=new Uint8Array(roads.nodes.length);distance[source]=0;const q=[[0,source]];
 while(q.length){q.sort((a,b)=>a[0]-b[0]);const [d,u]=q.shift();if(used[u]||d>distance[u])continue;used[u]=1;if(u===target)break;for(const ei of adj[u]){const e=roads.edges[ei],v=e.a===u?e.b:e.a,s=statuses?.get(e.id)||e.status;if(!possible(vehicle,s,e.kind,e.risk))continue;let cost=e.length/speeds[vehicle]*(vehicle==='boat'&&s==='open'?1.35:1)*(1+e.risk*.22);if(d+cost<distance[v]){distance[v]=d+cost;prev[v]=u;prevEdge[v]=ei;q.push([distance[v],v]);}}}
 if(!Number.isFinite(distance[target]))return null;const path=[],edgeIndices=[];for(let u=target;u!==source;u=prev[u]){if(prev[u]<0)return null;edgeIndices.push(prevEdge[u]);}edgeIndices.reverse();let at=source;path.push(from,roads.nodes[source].pos);for(const ei of edgeIndices){const e=roads.edges[ei],goingForward=e.a===at;const pts=goingForward?e.path:[...e.path].reverse();path.push(...pts.slice(1));at=goingForward?e.b:e.a;}path.push(to);return{points:path,edges:edgeIndices.map(i=>roads.edges[i].id),distance:path.slice(1).reduce((sum,p,i)=>sum+metres(path[i],p),0),cost:distance[target],vehicle};}
class SearchAgent{
 constructor(spec,publicRegions,teams,seed){this.id=spec.id;this.vehicle=spec.vehicle;this.sector=spec.sector;this.launchSite=spec.launchSite;this.pos={...spec.start};this.start={...spec.start};this.down=false;this.seq=0;this.log=new Map();this.history=[];this.peerCursors=new Map();this.progress=new Map();this.knownFound=new Map();this.visibleRegions=new Map(publicRegions.map(r=>[r.id,{id:r.id,name:r.name,pos:{...r.pos},expected:r.expected,rawRisk:r.rawRisk,priority:r.priority,manual:r.manual,shape:r.shape,radius:r.radius,sector:r.sector}]));this.lastKnown=new Map(teams.map(t=>[t.id,{tick:0,pos:t.start}]));this.target=null;this.path=null;this.pathIndex=0;this.strategy=0;this.q=[0,0,0];this.choices=[0,0,0];this.visits=0;this.random=rng(seed+spec.id.length*191+Number(spec.id.replace(/\D/g,''))*17);this.takeover=false;this.distanceM=0;this.speedMPerTick=0;this.flightTrail=[{...spec.start}];this.waitingRescue=false;this.dispatchJob=null;this.lastPeerTick=-1;this.battery=100;this.flightState='launching';this.rechargeTicks=0;this.lastSensor=[];this.handoverCleared=false;this.lastProgressTick=0;}
 append(tick,type,data){const event={id:`${this.id}#${++this.seq}`,origin:this.id,tick,type,...data};this.receive(event);return event;}
 receive(ev){if(this.log.has(ev.id))return false;this.log.set(ev.id,ev);this.history.push(ev);if(ev.type==='SURVEY'){this.progress.set(ev.region,(this.progress.get(ev.region)||0)+ev.amount);this.knownFound.set(ev.region,(this.knownFound.get(ev.region)||0)+ev.found);}if(ev.type==='HEARTBEAT')this.lastKnown.set(ev.team,{tick:ev.tick,pos:ev.pos});if(ev.type==='ADD_REGION')this.visibleRegions.set(ev.region.id,{...ev.region});return true;}
 merge(other){let merged=0;for(const e of other.log.values())if(this.receive(e))merged++;return merged;}
 choose(worldTick,teamSpecs,terrain,center){
 const options=[];
 for(const reg of this.visibleRegions.values()){
  const effort=this.progress.get(reg.id)||0, found=this.knownFound.get(reg.id)||0;
  // Non-drone units make one primary survey. Drones perform repeat patrol passes, even after 99% of the estimate.
  if(this.vehicle!=='drone'&&effort>=.999)continue;
  if(this.vehicle==='drone'&&this.waitingRescue&&this.target===reg.id)return reg.id;
  const owner=teamSpecs.find(t=>t.vehicle==='drone'&&t.sector===reg.sector);
  const ownerStale=owner&&owner.id!==this.id&&worldTick-(this.lastKnown.get(owner.id)?.tick||0)>13;
  if(this.vehicle==='drone'&&reg.sector!==this.sector){
   const home=[...this.visibleRegions.values()].filter(z=>z.sector===this.sector);
   const homeFinished=home.every(z=>(this.progress.get(z.id)||0)>=.99);
   // No early quadrant switching: recover a missing peer only after locally finishing our sector and a handover.
   if(!ownerStale||!homeFinished||!this.handoverCleared||this.waitingRescue)continue;
  }
  const d=metres(this.pos,reg.pos),risk=reg.rawRisk;
  const initial=effort<1,remaining=initial?1-Math.min(1,effort):(.17/(1+Math.floor(effort)));
  const benefit=remaining*Math.sqrt(reg.expected+2),priority=reg.priority*4+risk*12;
  const home=reg.sector===this.sector,ownership=home?1.6:ownerStale?1.1:1;
  const searchBias=initial?1.8:.55;
  const dist=1+d/480;
  const potentials=[(benefit+priority*searchBias)*ownership/dist,
   (risk*24*searchBias+priority+benefit*.24)*ownership/Math.sqrt(dist),
   (benefit*1.8+priority*.5*searchBias)*ownership/Math.pow(dist,.72)];
  options.push({reg,ownerStale,score:potentials,effort});
 }
 if(!options.length)return null;
 const epsilon=.14;this.strategy=this.random()<epsilon?Math.floor(this.random()*3):this.q.indexOf(Math.max(...this.q));this.choices[this.strategy]++;
 // A finished first-pass zone gets a lower priority, but is never permanently removed from drone searches.
 options.sort((a,b)=>Number(a.effort>=1)-Number(b.effort>=1)||(a.effort>=1&&b.effort>=1?Math.floor(a.effort)-Math.floor(b.effort):0)||b.score[this.strategy]-a.score[this.strategy]||a.reg.id.localeCompare(b.reg.id));
 this.takeover=!!options[0].ownerStale;return options[0].reg.id;
}
 learn(reward){this.q[this.strategy]+=.11*(reward-this.q[this.strategy]);}
}
export class World{
 constructor(scenario,mode='distributed'){this.scenario=scenario;this.mode=mode;this.tick=0;this.mastUp=true;this.floodLevel=0;this.regions=scenario.regions.map(r=>({...r}));this.teams=scenario.teams.map(t=>({...t}));this.agents=this.teams.map(t=>new SearchAgent(t,this.regions,this.teams,scenario.seed));this.graph=scenario.roads;this.adj=adjacency(this.graph);this.actualRoads=new Map(this.graph.edges.map(e=>[e.id,'open']));this.hq=new Map();this.pendingCommand=[];this.recommendations=[];this.approved=[];this.audit=[];this.syncCount=0;this.hqCursors=new Map();this.manualCounter=0;this.selectedRoute=null;this.networkedPopulation=0;this.dispatchAssignments=new Map();this.resyncDelta=0;this.resyncAt=-1;this.peerSyncDuringOutage=0;this.mastLostAt=-1;this.lastRecovery=null;this.lastEvent='Teams deployed.';this.worldVersion=0;this.mobilityRandom=rng(scenario.seed+78923);this.maxDroneSpeedKmh=50;this.detectionRandom=rng(scenario.seed+440181);}
 timeline(message){this.lastEvent=message;this.audit.unshift({tick:this.tick,text:message});if(this.audit.length>35)this.audit.length=35;}
 getAgent(id){return this.agents.find(a=>a.id===id)}
 team(id){return this.teams.find(t=>t.id===id)}
 setMast(up){
  up=!!up;
  if(this.mastUp===up)return;
  this.mastUp=up;
  if(!up){
   this.mastLostAt=this.tick;
   this.lastRecovery=null;
   this.timeline('NETWORK FAILURE: command positions frozen. Drones continue locally and can exchange short-range radio data.');
   return;
  }
  const previouslyKnown=new Set(this.hq.keys());
  this.synchronize(true);
  const received=[...this.hq.values()].filter(e=>!previouslyKnown.has(e.id)&&e.origin!=='command'&&e.tick>=this.mastLostAt);
  const surveyReports=received.filter(e=>e.type==='SURVEY');
  this.resyncDelta=surveyReports.reduce((sum,e)=>sum+(e.found||0),0);
  this.resyncAt=this.tick;
  const teams=[...new Set(received.map(e=>e.origin))].sort();
  const regions=[...new Set(surveyReports.map(e=>e.region))].sort();
  this.lastRecovery={
   id:`respond-${this.scenario.seed}-${this.mastLostAt}-${this.tick}`,
   startedTick:this.mastLostAt,restoredTick:this.tick,durationMinutes:this.tick-this.mastLostAt,
   reportsReconciled:received.length,surveyReports:surveyReports.length,
   newlyLocated:this.resyncDelta,teams,regions,
   // Bounded compact log of fictional observations; raw real-world citizen records are never transmitted.
   sampleEvents:received.filter(e=>e.type==='SURVEY'||e.type==='POWER'||e.type==='HANDOVER').slice(-250).map(e=>({...e})),
   additionalEventsOmitted:Math.max(0,received.filter(e=>e.type==='SURVEY'||e.type==='POWER'||e.type==='HANDOVER').length-250)
  };
  this.timeline(`Mast restored: ${received.length} offline observations reconciled; ${this.resyncDelta} located people now reported to command.`);
 }
 recoveryPayload(){
  if(!this.lastRecovery)return null;
  const r=this.lastRecovery,byId=new Map(this.regions.map(z=>[z.id,z]));
  const targets=[
   {id:'council',label:'Local council emergency management',purpose:'Flood impacts, road access and affected search regions'},
   {id:'rescue',label:'Rescue-team leaders',purpose:'New sightings, priority areas and pending dispatch'},
   {id:'media',label:'News outlets (verified exercise contacts)',purpose:'Approved public situation bulletin — not live operational data'}
  ];
  return{
   schema:'respond.recovery.v1',batchId:r.id,trainingOnly:true,requiresVerifiedRecipients:true,
   product:'RESPOND',event:'MAST_RESTORED',scenario:this.scenario.area,
   recovery:{...r,regions:r.regions.map(id=>({id,name:byId.get(id)?.name||id}))},
   recipients:targets,summary:{expected:this.expected(),hqLocated:this.commandView().reported,offlineNewlyLocated:r.newlyLocated,floodStage:this.floodLevel},
   affectedRegions:r.regions.map(id=>{const reg=byId.get(id);return{id,name:reg?.name||id,estimatedPeople:reg?.expected||0,located:reg?.found||0,priority:reg?.priority||1}}),
   roadClosures:[...this.actualRoads].filter(([,status])=>status!=='open').map(([id,status])=>({id,status})),
   disclaimer:'FICTIONAL TRAINING EXERCISE. Not verified or authorized for public emergency alerts.'
  };
 }

 flood(level){this.floodLevel=clamp(Math.round(level),0,3);let changed=0;for(const e of this.graph.edges){const status=e.risk>([2,.82,.57,.33][this.floodLevel])?(this.floodLevel===3&&e.risk>.91?'blocked':'boat_only'):'open';if(this.actualRoads.get(e.id)!==status)changed++;this.actualRoads.set(e.id,status);}this.worldVersion++;this.agents.forEach(a=>a.path=null);this.timeline(`Flood stage ${['normal','rising','severe','critical'][this.floodLevel]}: ${changed} road segments changed.`);}
 markRoad(edgeId,status){if(!this.actualRoads.has(edgeId))return false;this.actualRoads.set(edgeId,status);this.worldVersion++;this.agents.forEach(a=>a.path=null);this.timeline(`Road ${edgeId}: ${status}.`);return true;}
 ground(id){const a=this.getAgent(id),t=this.team(id);if(!a||!t)return false;a.down=!a.down;t.down=a.down;if(a.down){a.speedMPerTick=0;a.dispatchJob=null;this.dispatchAssignments.delete(a.id);}else a.append(this.tick,'HEARTBEAT',{team:a.id,pos:{...a.pos}});this.timeline(`${t.name} ${a.down?'unresponsive; search region at risk':'reactivated'}.`);return a.down;}
 moveStart(id,pos){const a=this.getAgent(id),t=this.team(id);if(!a||!t)return false;a.start={...pos};a.pos={...pos};a.flightTrail=[{...pos}];a.distanceM=0;a.target=null;a.path=null;t.start={...pos};this.timeline(`${t.name} redeployed to new launch point.`);return true;}
 addSearchRegion({lat,lng,name='New priority search',expected=0,priority=3}={}){if(!Number.isFinite(lat)||!Number.isFinite(lng))throw Error('Invalid coordinates');expected=clamp(Math.floor(Number(expected)||0),0,50000-this.expected());const random=rng(this.scenario.seed+this.manualCounter*1337+880),id=`M${++this.manualCounter}`;const p={lat,lng},reg={id,name,pos:p,expected,present:expected,found:0,surveyed:0,passes:0,atRisk:Math.round(expected*.14),rawRisk:rawRisk(p,this.scenario.terrain,this.scenario.center),priority:clamp(+priority,1,3),sector:sectorOf(p,this.scenario.center,this.scenario.sectors)||([...(this.scenario.sectors||[])].sort((a,b)=>metres(p,a.center)-metres(p,b.center))[0]?.id||null),radius:150,shape:Math.floor(random()*10000),manual:true,unexpected:0,sweepEffort:0};this.regions.push(reg);
 // Assign each new resident to exactly one added region. Existing assignments never change.
 const old=this.scenario.assignments,arr=new Uint16Array(old.length+expected);arr.set(old);arr.fill(this.regions.length-1,old.length);this.scenario.assignments=arr;this.scenario.people+=expected;
 const event={id:`command#${this.manualCounter}`,origin:'command',tick:this.tick,type:'ADD_REGION',region:{id,name,pos:p,expected,rawRisk:reg.rawRisk,priority:reg.priority,sector:reg.sector,manual:true}};this.hq.set(event.id,event);this.pendingCommand.push(event);this.timeline(`New search region ${name} added (${expected} expected). Pending transmission to agents.`);return reg;}
 expected(){return this.regions.reduce((s,r)=>s+r.expected,0)}
 connected(a,b){return !a.down&&!b.down&&(metres(a.pos,b.pos)<230||this.mastUp);}
 // Receives only radio/internet messages; no privileged world state leaks to actors.
 synchronize(force=false){if(!force&&this.tick%3)return;
 for(let i=0;i<this.agents.length;i++)for(let j=i+1;j<this.agents.length;j++){
   const a=this.agents[i],b=this.agents[j];if(a.down||b.down||!this.connected(a,b))continue;
   // Incremental delta gossip, rather than resending each actor's full event log to every peer.
   const aEnd=a.history.length,bEnd=b.history.length;
   const newForB=a.history.slice(b.peerCursors.get(a.id)||0);
   const newForA=b.history.slice(a.peerCursors.get(b.id)||0);
   b.peerCursors.set(a.id,aEnd);a.peerCursors.set(b.id,bEnd);
   for(const ev of newForB)if(b.receive(ev)){this.syncCount++;if(!this.mastUp){this.peerSyncDuringOutage++;b.lastPeerTick=this.tick;}}
   for(const ev of newForA)if(a.receive(ev)){this.syncCount++;if(!this.mastUp){this.peerSyncDuringOutage++;a.lastPeerTick=this.tick;}}
 }
 // Human-entered search areas reach only connected agents; isolated actors learn later.
 if(this.mastUp){for(const a of this.agents)if(!a.down){for(const e of this.pendingCommand)a.receive(e);
   const end=a.history.length,start=this.hqCursors.get(a.id)||0;
   for(let i=start;i<end;i++){const ev=a.history[i];this.hq.set(ev.id,ev);}
   this.hqCursors.set(a.id,end);
 }this.pendingCommand.length=0;}
 }
 searchRegion(a,region){
  // The world owns ground truth; drones receive only sampled reports and modelled coordinates.
  // Surveying takes ~40 simulated minutes per full pass; additional passes may uncover people missing from estimates.
  const footprint=a.vehicle==='drone'?.025:.018;
  const previous=region.sweepEffort||0,effort=previous+footprint;
  region.sweepEffort=effort;region.surveyed=Math.min(1,effort);region.passes++;
  // A first pass detects almost all registered residents; later sweeps reveal missed and unregistered residents.
  const firstPass=.995*Math.min(1,effort);
  const nextPass=.005*clamp(effort-1,0,1);
  const hiddenPass=clamp((effort-1)*.58,0,1);
  const goal=Math.min(region.present+region.unexpected,Math.floor(region.present*Math.min(1,firstPass+nextPass)+1e-8)+Math.floor(region.unexpected*hiddenPass));
  const discovered=Math.max(0,goal-region.found);
  region.found+=discovered;
  if(a.vehicle==='drone'){
   const old={...a.pos};const theta=this.tick*.23+region.shape*.005+effort*3.4;
   const point=metersToLL(region.pos,Math.sin(theta)*Math.min(68,region.radius*.47),Math.cos(theta)*Math.min(65,region.radius*.43));
   const d=metres(old,point);a.pos=interpolate(old,point,Math.min(1,Math.min(65,MAX_DRONE_METRES_PER_TICK)/Math.max(.01,d)));
   const moved=metres(old,a.pos);a.distanceM+=moved;a.speedMPerTick=moved;
   a.flightTrail.push({...a.pos});if(a.flightTrail.length>260)a.flightTrail.shift();
  }
  const sightings=[];
  if(discovered){
   const clusters=Math.min(3,discovered);let remaining=discovered;
   for(let i=0;i<clusters;i++){
    const n=Math.floor(remaining/(clusters-i)),seed=rng(this.scenario.seed+this.tick*419+region.shape*71+i*941);
    const bearing=seed()*Math.PI*2,rad=10+seed()*Math.min(56,region.radius*.4);
    const pt=metersToLL(region.pos,Math.cos(bearing)*rad,Math.sin(bearing)*rad);
    sightings.push({lat:pt.lat,lng:pt.lng,count:n});remaining-=n;
   }
  }
  a.visits++;a.lastProgressTick=this.tick;
  a.append(this.tick,'SURVEY',{region:region.id,amount:footprint,found:discovered,pos:{...a.pos},sightings,pass:Math.floor(effort)+1});
  a.learn(footprint*40+discovered*.6+(a.takeover?8:0));
  if(discovered&&region.atRisk>0&&!region.responderArrived){
   region.needsRescue=true;
   if(!this.recommendations.some(r=>r.region===region.id&&['pending','approved','queued'].includes(r.status)))
    this.recommendations.push({id:`dispatch-${region.id}-${this.tick}`,region:region.id,name:region.name,reportedBy:a.id,found:discovered,priority:region.priority,status:'pending',pos:region.pos,tick:this.tick});
  }
  // Change tasks after each completed sweep, or when 99% of the expected population is detected.
  // Later idle time is used for fresh patrols, not waiting for a task list to become nonempty.
  const completedPass=Math.floor(effort+1e-7)>Math.floor(previous+1e-7);
  const expectedReached=region.expected>0&&region.found>=Math.ceil(region.expected*.99);
  if(completedPass||(expectedReached&&effort>=.99&&previous<.99)){
   if(a.vehicle==='drone'&&region.needsRescue&&!region.responderArrived){a.waitingRescue=true;a.target=region.id;a.flightState='holding-for-rescue';}
   else{a.target=null;a.path=null;a.waitingRescue=false;}
  }
  if(discovered&&this.tick%4===0)this.timeline(`${a.id} located ${discovered} people in ${region.name}${region.found>region.expected?' (above estimate)':''}.`);
 }
 loiter(a,region){
  // Loiter near a found rescue site, without leaving the assigned rectangular sector.
  const sector=this.scenario.sectors.find(x=>x.id===a.sector);
  const anchor=toLocal(region.pos,this.scenario.center),angle=(this.tick*.48+(a.seq%20)*.02);
  let x=anchor.x+Math.cos(angle)*25,y=anchor.y+Math.sin(angle)*25;
  if(sector){x=clamp(x,sector.minX+6,sector.maxX-6);y=clamp(y,sector.minY+6,sector.maxY-6);}
  const destination=metersToLL(this.scenario.center,x,y),old={...a.pos},distance=metres(old,destination);
  a.pos=interpolate(old,destination,Math.min(1,38/Math.max(.01,distance)));
  const moved=metres(old,a.pos);a.distanceM+=moved;a.speedMPerTick=moved;
  a.flightTrail.push({...a.pos});if(a.flightTrail.length>260)a.flightTrail.shift();
 }
 travel(a,reg){
  const old={...a.pos},destination=reg.pos;
  if(a.vehicle==='drone'){
   const distance=metres(a.pos,destination),ratio=Math.min(1,Math.min(speeds.drone,MAX_DRONE_METRES_PER_TICK)/Math.max(.01,distance));
   const next=interpolate(a.pos,destination,ratio),sweep=Math.sin(this.tick*.24+a.seq*.31)*.000014;
   next.lat+=sweep;next.lng+=sweep*.8;a.pos=next;
  }else{
   if(!a.path){const r=route(this.graph,this.adj,a.pos,destination,a.vehicle,this.actualRoads);if(!r){a.target=null;return;}a.path=r.points;a.pathIndex=1;}
   let remaining=speeds[a.vehicle];while(remaining>.01&&a.pathIndex<a.path.length){
    const next=a.path[a.pathIndex],d=metres(a.pos,next);
    if(d<remaining){a.pos={...next};remaining-=d;a.pathIndex++;}
    else{a.pos=interpolate(a.pos,next,remaining/d);remaining=0;}
   }
   if(a.pathIndex>=a.path.length)a.path=null;
  }
  const traveled=metres(old,a.pos);a.distanceM+=traveled;a.speedMPerTick=traveled;
  if(a.vehicle==='drone'&&(this.tick%1===0)){a.flightTrail.push({...a.pos});if(a.flightTrail.length>260)a.flightTrail.shift();}
 }

 // Simulated civilian relocation: current positions can change; baseline expected counts do not.
 // Every resident keeps exactly one current region assignment in the typed array.
 moveCivilians(){if(this.tick%8!==0||this.regions.length<2)return;
   const r=this.mobilityRandom,origins=this.regions.filter(z=>z.present-z.found>=4).sort((a,b)=>b.rawRisk-a.rawRisk);
   if(!origins.length)return;const src=origins[Math.floor(r()*Math.max(1,Math.floor(origins.length*.6)))];
   const dests=this.regions.filter(z=>z.id!==src.id&&z.rawRisk<src.rawRisk+.1).sort((a,b)=>metres(src.pos,a.pos)-metres(src.pos,b.pos));
   if(!dests.length)return;const dst=dests[Math.floor(r()*Math.min(6,dests.length))],i=this.regions.indexOf(src),j=this.regions.indexOf(dst);
   const amount=Math.min(Math.max(1,Math.round(this.scenario.people*.00024)),src.present-src.found);let moved=0;
   for(let k=0;k<this.scenario.assignments.length&&moved<amount;k++)if(this.scenario.assignments[k]===i){this.scenario.assignments[k]=j;moved++;}
   if(moved){src.present-=moved;dst.present+=moved;const transfer=Math.min(Math.max(0,src.atRisk-src.found),Math.round(moved*(.12+src.rawRisk*.2)));src.atRisk-=transfer;dst.atRisk+=transfer;
     if(this.tick%24===0)this.timeline(`Modelled civilian movement near ${src.name}; responders may hold outdated information.`);}
 }
 dronePower(a){
  if(a.vehicle!=='drone')return false;
  const pads=this.scenario.launchSites;
  if(!pads.length)return false;
  const reserved=new Set(this.agents.filter(d=>d.id!==a.id&&d.vehicle==='drone'&&!d.down&&['returning','charging'].includes(d.flightState)&&d.rechargeSite).map(d=>d.rechargeSite));
  const nearest=[...pads].filter(p=>!reserved.has(p.id)).sort((x,y)=>metres(a.pos,x.pos)-metres(a.pos,y.pos))[0];
  const pad=pads.find(s=>s.id===a.rechargeSite);
  if(a.flightState==='charging'){
   a.speedMPerTick=0;a.rechargeTicks++;a.battery=Math.min(100,a.battery+5);
   if(a.rechargeTicks>=20||a.battery>=100){a.battery=100;a.rechargeTicks=0;a.rechargeSite=null;a.flightState='returning-to-sector';a.append(this.tick,'POWER',{state:'recharged',battery:100});}
   return true;
  }
  if(a.flightState==='returning'){
   if(!pad){a.flightState='surveying';return false;}
   if(metres(a.pos,pad.pos)<35){a.pos={...pad.pos};a.flightState='charging';a.rechargeTicks=0;a.speedMPerTick=0;a.append(this.tick,'POWER',{state:'charging',battery:a.battery});return true;}
   this.travel(a,{pos:pad.pos});a.battery=clamp(a.battery-1.3,0,100);return true;
  }
  const nearestAny=[...pads].sort((x,y)=>metres(a.pos,x.pos)-metres(a.pos,y.pos))[0];
  const reference=nearest||nearestAny,homeMinutes=metres(a.pos,reference.pos)/speeds.drone;
  const reserve=9+homeMinutes*1.25;
  if(a.battery<=Math.max(22,reserve)){
   if(!nearest){a.flightState='awaiting-free-pad';a.speedMPerTick=0;return true;}
   a.rechargeSite=nearest.id;a.flightState='returning';a.path=null;
   a.append(this.tick,'POWER',{state:'returning-to-charge',battery:a.battery,staging:nearest.id});
   this.timeline(`${a.id} battery ${Math.round(a.battery)}% — returning to free pad ${nearest.name}.`);
   this.travel(a,{pos:nearest.pos});a.battery=clamp(a.battery-1.3,0,100);return true;
  }
  if(a.flightState==='awaiting-free-pad')a.flightState='surveying';
  a.battery=clamp(a.battery-.95,0,100);
  if(['launching','returning-to-sector','holding-for-rescue'].includes(a.flightState)&&!a.waitingRescue)a.flightState='surveying';
  return false;
 }
 step(){
 this.tick++;this.moveCivilians();
 const teamSpecs=this.teams.map(t=>({id:t.id,vehicle:t.vehicle,start:t.start,sector:t.sector}));
 for(const a of this.agents){
  if(a.down)continue;a.speedMPerTick=0;
  const powerHandled=this.dronePower(a);
  if(this.tick%4===0)a.append(this.tick,'HEARTBEAT',{team:a.id,pos:{...a.pos},battery:a.vehicle==='drone'?a.battery:null,flightState:a.flightState,rechargeSite:a.rechargeSite});
  if(powerHandled)continue;
  if(a.dispatchJob){
   const task=this.regions.find(r=>r.id===a.dispatchJob);
   if(task){
    if(metres(a.pos,task.pos)<Math.max(75,task.radius*.3)){
     task.responderArrived=true;task.needsRescue=false;
     for(const d of this.agents)if(d.vehicle==='drone'&&d.target===task.id){d.waitingRescue=false;d.handoverCleared=true;d.append(this.tick,'HANDOVER',{region:task.id});}
     this.timeline(`${a.id} reached ${task.name}; search drone released.`);
     a.dispatchJob=null;this.dispatchAssignments.delete(a.id);a.path=null;a.target=null;
    }else this.travel(a,task);
    continue;
   }a.dispatchJob=null;
  }
  if(a.waitingRescue){
   const held=this.regions.find(r=>r.id===a.target);
   if(held&&!held.responderArrived){a.flightState='holding-for-rescue';if(a.vehicle==='drone')this.loiter(a,held);continue;}
   a.waitingRescue=false;a.target=null;a.path=null;a.flightState='surveying';
  }
  if(!a.target||!a.visibleRegions.has(a.target)||(a.vehicle!=='drone'&&(a.progress.get(a.target)||0)>=.999)){
   a.target=null;a.path=null;
   if(this.mode==='central'&&!this.mastUp)continue;
   a.target=a.choose(this.tick,teamSpecs,this.scenario.terrain,this.scenario.center);
  }
  if(!a.target){if(a.vehicle==='drone')a.flightState='patrolling';continue;}const reg=this.regions.find(r=>r.id===a.target);if(!reg)continue;
  if(metres(a.pos,reg.pos)<Math.max(70,reg.radius*.3)){if(a.vehicle==='drone')a.flightState='surveying';this.searchRegion(a,reg);}
  else this.travel(a,reg);
 }
 this.synchronize();this.processQueue();
 }

 rescueRoute(regionId,vehicle){const reg=this.regions.find(r=>r.id===regionId);if(!reg)return null;const routes=this.scenario.shelters.map(s=>({...route(this.graph,this.adj,s.pos,reg.pos,vehicle,this.actualRoads),staging:s.name})).filter(x=>Number.isFinite(x.cost));routes.sort((a,b)=>a.cost-b.cost);return routes[0]||null;}
 routeOptions(regionId){return ['car','boat','foot'].map(vehicle=>({vehicle,route:this.rescueRoute(regionId,vehicle)}));}
 nearestResponder(regionId){
  const reg=this.regions.find(r=>r.id===regionId);if(!reg)return null;
  return this.agents.filter(a=>a.vehicle!=='drone'&&!a.down&&!a.dispatchJob)
   .map(a=>({agent:a,route:route(this.graph,this.adj,a.pos,reg.pos,a.vehicle,this.actualRoads)}))
   .filter(x=>x.route&&Number.isFinite(x.route.cost))
   .sort((a,b)=>a.route.cost-b.route.cost||a.agent.id.localeCompare(b.agent.id))[0]||null;
 }
 approve(id,decision){
  const rec=this.recommendations.find(r=>r.id===id);
  if(!rec||rec.status!=='pending')return false;
  if(decision!=='approved'){rec.status='held';this.timeline(`Commander held dispatch for ${rec.name}.`);return true;}
  const assigned=this.nearestResponder(rec.region);
  if(!assigned){rec.status='queued';this.timeline(`No accessible free responder to ${rec.name}; dispatch queued.`);return true;}
  // During a mast outage, a central order cannot magically reach a disconnected field unit.
  if(!this.mastUp){rec.status='queued';rec.queuedResponder=assigned.agent.id;this.timeline(`Dispatch to ${rec.name} queued until communication returns.`);return true;}
  this.assignDispatch(rec,assigned.agent.id);
  return true;
 }
 assignDispatch(rec,responderId){
  const agent=this.getAgent(responderId);if(!agent||agent.vehicle==='drone'||agent.down)return false;
  agent.dispatchJob=rec.region;agent.target=null;agent.path=null;this.dispatchAssignments.set(responderId,rec.region);
  rec.status='approved';rec.assignedTo=responderId;
  this.approved.push({...rec,reviewedAt:this.tick});
  this.timeline(`Commander approved ${rec.name}: only ${responderId} deployed. All other teams continue surveying.`);
  return true;
 }
 processQueue(){
  if(!this.mastUp)return;
  for(const rec of this.recommendations.filter(r=>r.status==='queued')){
   const closest=this.nearestResponder(rec.region);if(closest)this.assignDispatch(rec,closest.agent.id);
  }
 }

 simSummary(){const expected=this.expected(),found=this.regions.reduce((sum,r)=>sum+r.found,0),known=new Set([...this.hq.values()].filter(e=>e.type==='SURVEY').map(e=>e.id));const reported=[...this.hq.values()].filter(e=>e.type==='SURVEY').reduce((s,e)=>s+e.found,0),suspected=this.agents.filter(a=>a.down||this.tick-(this.hqLastHeartbeat(a.id)||0)>13).map(a=>a.id);return{tick:this.tick,expected,found,reported,unverified:Math.max(0,expected-found),suspected,regions:this.regions.length,signals:this.syncCount};}
 commandView(){
  const locatedByRegion=new Map(),coverageByRegion=new Map(),lastSeen=new Map();
  for(const ev of this.hq.values()){
   if(ev.type==='SURVEY'){locatedByRegion.set(ev.region,(locatedByRegion.get(ev.region)||0)+ev.found);coverageByRegion.set(ev.region,Math.min(1,(coverageByRegion.get(ev.region)||0)+ev.amount));}
   if(ev.type==='HEARTBEAT'&&(!lastSeen.has(ev.team)||lastSeen.get(ev.team).tick<ev.tick))lastSeen.set(ev.team,{tick:ev.tick,pos:ev.pos,battery:ev.battery,flightState:ev.flightState,rechargeSite:ev.rechargeSite});
  }
  return{locatedByRegion,coverageByRegion,lastSeen,reported:[...locatedByRegion.values()].reduce((a,b)=>a+b,0)};
 }
 hqLastHeartbeat(id){let t=0;for(const ev of this.hq.values())if(ev.type==='HEARTBEAT'&&ev.team===id)t=Math.max(t,ev.tick);return t;}
 situationReport(){return{title:'RESPOND training simulation — not an operational report',area:this.scenario.area,center:this.scenario.center,stage:this.floodLevel,communications:this.mastUp?'online':'offline',summary:this.simSummary(),regionalStatus:this.regions.map(r=>({id:r.id,name:r.name,expected:r.expected,located:r.found,covered:Math.round(r.surveyed*100),priority:r.priority})),dispatches:this.approved,roadClosures:[...this.actualRoads].filter(([,s])=>s!=='open').map(([id,status])=>({id,status})),sectors:this.scenario.sectors.map(s=>({id:s.id,areaKm2:s.areaKm2})),dispatchAssignments:[...this.dispatchAssignments],independentAgentLogs:this.agents.map(a=>({id:a.id,sector:a.sector,metresFlown:Math.round(a.distanceM),events:a.log.size,down:a.down}))};}
 populationValid(){const arr=this.scenario.assignments,extra=this.scenario.unregisteredAssignments||[];if(arr.length!==this.expected()||!arr.every(i=>i>=0&&i<this.regions.length)||!Array.from(extra).every(i=>i>=0&&i<this.regions.length))return false;const counts=new Uint32Array(this.regions.length),extras=new Uint32Array(this.regions.length);for(const idx of arr)counts[idx]++;for(const idx of extra)extras[idx]++;return this.regions.every((r,i)=>r.present===counts[i]&&(r.unexpected||0)===extras[i]);}
}
