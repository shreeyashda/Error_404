from pathlib import Path
import re
root=Path(__file__).resolve().parent
engine=(root/'src/engine.js').read_text()
engine=re.sub(r'\bexport\s+(?=(?:const|function|class)\b)','',engine)
app=(root/'src/app.js').read_text()
app=re.sub(r"^import\s+\{[^\n]+\}\s+from\s+['\"]\./engine\.js['\"];?\s*\n",'',app,count=1)
css=(root/'src/style.css').read_text()
html=f'''<!DOCTYPE html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="referrer" content="strict-origin-when-cross-origin"><title>RESPOND · Regional Rescue Simulator</title><style>{css}</style></head><body><div id="app"></div><script>{engine}\n{app}</script></body></html>'''
(root/'standalone.html').write_text(html)
print('Standalone generated:',len(html),'bytes')
