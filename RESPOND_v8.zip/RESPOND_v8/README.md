# RESPOND v8 — Regional Emergency Surveillance Pinpointing Objectives in Natural Disasters

An offline-resilient flood-response simulation.

**Hackathon reference implementation, not operational emergency software.** All residents, geolocated sighting clusters, flight telemetry, flood conditions, routes and detection timing are synthetic. The browser simulation does not operate actual drones, radios or rescue dispatch; n8n delivery requires explicit setup.

## Quick start (Windows)

1. Extract `RESPOND_v8.zip`.
2. Double-click `RESPOND_v8/standalone.html` and open it in Chrome or Edge. No Node install or server required for the offline simulation.
3. Optionally switch to **Offline** map mode if remote OSM/terrain tiles do not load.
4. Before **Start**, drag your **Draw search rectangle** on the map, then **Choose launch point** to place each staging location **outside** the area. No more launch sites than drones are allowed; for 5+ drones you can add sites up to the number of drones.
5. Press **Start**. Select **Drone flight & local POV** to view onboard positions, flight path, estimated victim clusters with latitude and longitude, speed, battery level and synthetic sensor observations.
6. Click **Mast failure**. A full-screen **OFFLINE** alert appears. Choose **View a live local drone** to demonstrate search continuing without HQ, or **Continue with stale HQ view**. The command counters and positions freeze while local drone observations keep accumulating.
7. Restore the mast to see the synchronization banner, reconciled HQ counts, and updated last-known positions.

## Requested v7 changes

- **Local GPS view:** the selected drone reports its simulated WGS84 latitude/longitude. Recent sightings list *synthetic cluster coordinates* and a count per cluster. At high population densities these are aggregate detections, **not precise individual locations**.
- **Repeated search:** agents no longer permanently exclude 99%-complete regions. Drones revisit their sectors for additional passes, including synthetic *unregistered* residents that were not in the expected-population estimate. Every expected and extra resident is allocated to exactly one search region.
- **Movement/stopping fix:** a completed first sweep triggers another task selection; a rescue-site hold is a visible **loitering** state rather than an unexplained freeze. Charging and unavailable status remain explicit reasons for a drone not to advance.
- **Charging warnings:** HQ shows an amber battery alert for drones nearing ~20% or charging, with the proposed charging site when known. The drone reserves the **nearest unoccupied** external launch pad; multiple drones will not choose an already reserved pad if another is free.
- **Launch-site limit:** launch pads are capped at the number of drones (zero drones = zero pads), both for preset sites and custom additions. All pins must be outside the selected mission rectangle; this does **not** verify their real-world suitability.
- **Offline splash:** large red **OFFLINE** screen with an immediate **View a live local drone** action. A persistent red banner marks HQ information as stale.
- **Local autonomy:** the individual drone POV renders live onboard GPS, battery, logs, estimated people coordinates and sampled sensor data throughout a simulated mast outage. Peers exchange event logs if they pass within 230 simulated metres.

## Retained capabilities

- 1–50,000 expected residents and configurable responders/drones (0–30 ground/boat/foot teams; 0–20 drones).
- Rectangular search boundary, equal-area search sectors and proximity-based drone assignments, preflight external launch pins and later operator-added zones.
- Ground/boat dispatch approval goes only to one eligible responder, not the entire fleet.
- Drones use an adaptive Q-value search strategy with an approximately 40-simulated-minute initial survey pass per region. Drones hold near an active rescue site until simulated responder arrival, unless a safe battery return is required.
- Street and Terrain map modes load optional network tiles; the Offline view is self-contained.
- The main map does not draw the old synthetic blue river, although flooded boat-only road segments may still be blue and are identified in the map legend.

## Editing and testing

```bash
npm test        # Node 22+; 34 automated engine tests
npm run build   # Python; regenerates standalone.html
npm run serve   # Local web server at http://localhost:8000
```

The source is `src/engine.js` (simulation and agents), `src/app.js` (UI and offline controls), and `src/style.css` (styling). `build_standalone.py` packages these into one self-contained HTML file. A browser smoke test is at `tests/browser_v7.py` (requires Playwright and Chromium). `docs/TEAM_HANDOFF.md` documents integration boundaries.

## Limitations

Satellite, mobile and radio outages are modelled inside **one** browser, not transmitted between physical devices. The POV is a visualization of the local simulated agent, not a live camera feed. Sighting points are fictional and represent clusters. Drone flight time, battery, charging, hazard severity, terrain accessibility, and dispatch ETAs are not field-validated. Only imported OSM geometry is genuine; an online basemap alone does not imply accurate road or flood data. Actual rescue decisions require trained human oversight and verified inputs.

## v8 addition — systems restored and n8n notifications

After **Mast failure → Restore mast**, a **small green SYSTEMS BACK ONLINE** card appears with the number of field observations reconciled, newly reported located people, and three destination categories: **local councils**, **rescue team leadership**, and **news outlets**. Unlike the full-screen outage alert, it is non-blocking and automatically dismisses after approximately 10 seconds; there is also a close button.

The default standalone HTML is **demo-only**: the notifications are represented visually, but nothing is sent externally without n8n configuration. Click **⚡ n8n gateway** for an optional webhook URL, or run the included local Node relay as described in `n8n/README.md` to avoid browser CORS issues. The `n8n/RESPOND_recovery_workflow.json` import contains three labelled audience branches with safe No Operation endpoints. You must connect approved real destinations for actual delivery.

For a fully local proof-of-concept without n8n, restore the mast and use **Export n8n packet** to obtain the fictional recovery report JSON. With n8n enabled, RESPOND forwards the packet once per recovery and clearly distinguishes n8n's HTTP acknowledgment from real recipient delivery. Avoid using real council or news contacts in a hackathon demonstration without explicit authorisation.

```powershell
# Optional, runs a local gateway with a configured n8n endpoint:
$env:RESPOND_N8N_WEBHOOK_URL = 'http://localhost:5678/webhook/respond-recovery'
npm run gateway
# Visit http://localhost:8000
```
