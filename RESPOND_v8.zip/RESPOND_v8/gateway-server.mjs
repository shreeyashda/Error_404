// Optional local relay for RESPOND -> n8n. No external POST occurs without an
// explicitly configured RESPOND_N8N_WEBHOOK_URL environment variable.
import {createServer} from 'node:http';
import {readFile} from 'node:fs/promises';
import {join,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
const root=dirname(fileURLToPath(import.meta.url));
const webhook=process.env.RESPOND_N8N_WEBHOOK_URL||'';
const port=Number(process.env.PORT||8000);
function json(res,status,data){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(data));}
const server=createServer(async(req,res)=>{
  const pathname=new URL(req.url,'http://localhost').pathname;
  if(req.method==='GET'&&pathname==='/api/status')return json(res,200,{configured:!!webhook});
  if(req.method==='POST'&&pathname==='/api/recovery'){
    if(!webhook)return json(res,503,{error:'n8n webhook not configured; no messages sent'});
    try{
      let data='',bytes=0;
      for await(const chunk of req){bytes+=chunk.length;if(bytes>1_000_000){return json(res,413,{error:'Payload too large'});}data+=chunk;}
      const payload=JSON.parse(data);
      if(payload.schema!=='respond.recovery.v1'||payload.trainingOnly!==true||!payload.batchId)return json(res,422,{error:'Expected fictional RESPOND recovery batch'});
      const destination=new URL(webhook);
      if(destination.protocol!=='https:'&&!(destination.protocol==='http:'&&['localhost','127.0.0.1'].includes(destination.hostname)))return json(res,400,{error:'Use HTTPS or localhost for your n8n webhook'});
      const upstream=await fetch(destination,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload),signal:AbortSignal.timeout(12000)});
      if(!upstream.ok)return json(res,502,{error:`n8n returned HTTP ${upstream.status}`});
      return json(res,200,{acceptedBy:'n8n',batchId:payload.batchId,deliveredToRecipients:'unverified'});
    }catch(e){return json(res,502,{error:`n8n relay failed: ${String(e.message).slice(0,180)}`});}
  }
  if(req.method!=='GET')return json(res,405,{error:'Method not allowed'});
  const files={'/':'standalone.html','/standalone.html':'standalone.html','/index.html':'index.html','/src/app.js':'src/app.js','/src/engine.js':'src/engine.js','/src/style.css':'src/style.css'};
  if(!files[pathname])return json(res,404,{error:'Not found'});
  try{
    const body=await readFile(join(root,files[pathname]));
    const type=pathname.endsWith('.js')?'text/javascript':pathname.endsWith('.css')?'text/css':'text/html';
    res.writeHead(200,{'Content-Type':type+'; charset=utf-8','Cache-Control':'no-store'});res.end(body);
  }catch{return json(res,404,{error:'File not found'});}
});
server.listen(port,'127.0.0.1',()=>console.log(`RESPOND ready: http://localhost:${port} · n8n ${webhook?'configured':'OFF (demo only)'}`));
